package com.keywordSuper;

public class Details extends Car{
           public int year;
	public Details(String name, int year) {
		super(name);
		this.year=year;
		System.out.println(name+" "+year);
		
	}
	public Details() {
		this("KIA", 2024);
		System.out.println("default constructor");
		
		
	}
	public void m2() {
		super.id=34;
		
		System.out.println("m2 from details, id is "+id);
		super.m1();
	}
	public static void main(String[] args) {
		Details d=new Details();
		d.m2();
	}
}
