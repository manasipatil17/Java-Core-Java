package com.keywordSuper;

public class Car {
public int id=12;
public String name;

public Car(String name) {
	this.name=name;
}
public void m1() {
	
	System.out.println("m1 from Car, id is "+this.id);
}
}
