package com.arrayPractice2;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class VowelCons {
	
	public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String[] fruits = new String[5];

        // Accept 5 fruit names
        System.out.println("Enter 5 fruit names:");
        for (int i = 0; i < fruits.length; i++) {
            System.out.print("Fruit " + (i + 1) + ": ");
            fruits[i] = sc.nextLine().toLowerCase(); // store in lowercase for consistency
        }

        // Arrays to store vowels and consonants
        ArrayList<Character> a = new ArrayList<>(); // vowels
        ArrayList<Character> b = new ArrayList<>(); // consonants

        // Define vowels for easy checking
        String vowels = "aeiou";

        // Extract characters
        for (String fruit : fruits) {
            for (char ch : fruit.toCharArray()) {
                if (Character.isLetter(ch)) {
                    if (vowels.indexOf(ch) != -1) {
                        a.add(ch);
                    } else {
                        b.add(ch);
                    }
                }
            }
        }

        // Display results
        System.out.println("\nVowels (Array a): " + a);
        System.out.println("Consonants (Array b): " + b);
    }
}

