package com.arrayPractice2;

public class SecondLargest {
	//find second largest element in array.

public static void main(String[] args) {
	int arr[]= {12,32,14,55};
	
	int secLarge= Integer.MIN_VALUE;
	int largest=Integer.MIN_VALUE;
	
	for(int n:arr) {
		if( n>largest) {
		secLarge=largest;
		largest=n;
		}
		else if(n>secLarge && n!=largest) {
			secLarge=n;
		}
	}
	System.out.println("Second largest number is "+secLarge);
}
}
