package com.arrayPractice2;

public class LargestNumber {
// find largest element in array.

	public static void main(String[] args) {
		int arr[]= {11,54,23,75,66};
		int largest=arr[0];
		for(int i=0;i<arr.length;i++) {
			if(arr[i]>largest) {
				largest=arr[i];
			}
		}
		System.out.println("Largest number from array is "+largest);
	}
}
