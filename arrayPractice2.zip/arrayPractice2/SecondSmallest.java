package com.arrayPractice2;

public class SecondSmallest {
	//find second smallest element in array.

public static void main(String[] args) {
	int arr[]= {12,32,11,44};
	
	int secSmall=Integer.MAX_VALUE;
	int smallest=Integer.MAX_VALUE;
	
	for(int n:arr) {
		if(n<smallest) {
			secSmall=smallest;
			smallest=n;
		}
		else if(n<secSmall && n!=smallest) {
			secSmall =n;
		}
	}
	System.out.println("Second smallest number is "+secSmall);
}
}
