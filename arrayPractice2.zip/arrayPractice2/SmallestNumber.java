package com.arrayPractice2;

public class SmallestNumber {
	//find smallest element in array.
public static void main(String[] args) {
	int arr[]= {32,12,5,65};
	
	int smallest=arr[0];
	for(int i=0;i<arr.length;i++) {
		if(arr[i]<smallest) {
			smallest=arr[i];
		}
	}
	System.out.println("Smallest number from given array is "+smallest);
}
}
