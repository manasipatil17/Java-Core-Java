package com.inheritancePractice1.vehicle;

public class Vehicles {
public void start() {
	System.out.println("Vehicle used to travel from one place to another");
}
}
