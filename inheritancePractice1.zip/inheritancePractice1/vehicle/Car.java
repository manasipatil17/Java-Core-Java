package com.inheritancePractice1.vehicle;

public class Car extends Vehicles{
public void drive() {
	System.out.println("We can drive the car");
}
public static void main(String[] args) {
	Car c = new Car();
	c.start();
	c.drive();
}
}
