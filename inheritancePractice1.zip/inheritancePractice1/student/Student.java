package com.inheritancePractice1.student;

public class Student {
int rollNo=101;
String name="Manasi";

public void studentInfo() {
System.out.println("Student roll no : "+rollNo);
	System.out.println("Student name : "+name);
}
}
