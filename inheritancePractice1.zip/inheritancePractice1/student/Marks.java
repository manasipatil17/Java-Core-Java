package com.inheritancePractice1.student;

public class Marks extends Student {

	int sub1 =89;
	int sub2=90;
	int sub3=86;
	
	public void total() {
		System.out.println("Total marks obtained "+(sub1+sub2+sub3));
	}
	
	public static void main(String[] args) {
		Marks m=new Marks();
		m.studentInfo();
		System.out.println("Sub1 : "+m.sub1);
		System.out.println("Sub2 : "+m.sub2);
		System.out.println("Sub3 : "+m.sub3);
		m.total();
	}
}
