package com.inheritancePractice1.emp;

public class Employee {
 	
	public void empInfo(int id, String name) {
		System.out.println("Employee Id : "+id);
		System.out.println("Employee name : "+name);
		
	}
}
