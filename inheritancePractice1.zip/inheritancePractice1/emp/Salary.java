package com.inheritancePractice1.emp;

public class Salary extends Employee{

	double salary;
	
	public void salaryDetails(double salary) {
		this.salary=salary;
		
		System.out.println("Basic salary : "+salary);
		double hra=salary*0.2;
		System.out.println("HRA : "+hra);
		double da=salary*0.1;
		System.out.println("DA : "+da );
		System.out.println("Total salary : "+(salary+hra+da));
	}
	
	public static void main(String[] args) {
		Salary s=new Salary();
		s.empInfo(101,"Manasi");
		s.salaryDetails(30000);
		
	}
}
