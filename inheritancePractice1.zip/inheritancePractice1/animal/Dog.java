package com.inheritancePractice1.animal;

public class Dog extends Animal{
	public void bark() {
		System.out.println("dogs can bark.");
	}
	
	public static void main(String[] args) {
		Dog d=new Dog();
		d.eat();
		d.bark();
	}
}
