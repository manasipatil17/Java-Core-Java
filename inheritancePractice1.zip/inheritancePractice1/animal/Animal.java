package com.inheritancePractice1.animal;

public class Animal {
	public void eat() {
		System.out.println("Animals can eat.");
	}
}
