package com.inheritancePractice1.appliance;

public class Appliance {
	void turnOn() {
        System.out.println("Appliance is turned on.");
    }
}
