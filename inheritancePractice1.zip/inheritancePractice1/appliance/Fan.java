package com.inheritancePractice1.appliance;

public class Fan extends Appliance{
	void rotate() {
        System.out.println("Fan is rotating.");
    }
	
	public static void main(String[] args) {
		Fan f=new Fan();
		f.turnOn();
		f.rotate();
	}
}
