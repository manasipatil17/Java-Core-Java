package com.ThreadSynchronized;

public class Gaurav extends Thread {

	Radio r;

	public Gaurav(Radio obj) {
		r = obj;
	}

	@Override
	public void run() {
		r.play(108.2F);
	}

}
