package com.ThreadSynchronized;

public class Office {

	public static void main(String[] args) {
		
		Radio r = new Radio();
		
		Nilesh n = new Nilesh(r);
		Gaurav g = new Gaurav(r);
		Mansi m = new Mansi(r);
		
		n.start();
		g.start();
		m.start();
		
		
	}
	
}
