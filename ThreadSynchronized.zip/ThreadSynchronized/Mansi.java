package com.ThreadSynchronized;

public class Mansi extends Thread {

	Radio r;

	public Mansi(Radio obj) {
		r = obj;
	}

	@Override
	public void run() {
		r.play(94.3F);
	}

}

