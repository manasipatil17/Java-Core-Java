package com.set.treeSet;

import java.util.Iterator;
import java.util.TreeSet;

public class Demo {
	public static void main(String[] args) {
		TreeSet<Integer> v=new TreeSet();
		v.add(11);
		v.add(12);
		v.add(1);
		v.add(51);
		v.add(6);
		v.add(23);
		System.out.println(v.getLast());
		System.out.println(v.getFirst());
		System.out.println(v);
		System.out.println("-------------------------------------");
		//iteration can be done in 2 ways in vector	
		Iterator itr=v.iterator();
		while(itr.hasNext()) {
			System.out.println(itr.next());
		}
		System.out.println("-------------------------------------");
		for(Object o:v) {
			System.out.println(o);
		}
		System.out.println(v.contains(11));
		System.out.println(v.isEmpty());
	    v.remove(1);
		System.out.println(v);
		System.out.println(v.size());
		
		
	}
}
