package com.set.hashSet;

import java.util.HashSet;
import java.util.Iterator;

public class Demo {
public static void main(String[] args) {
	HashSet v=new HashSet();
	v.add("Ram");
	v.add(12);
	v.add(13.45);
	v.add('&');
	v.add("Ram");
	v.add(true);

	System.out.println(v);
	System.out.println("-------------------------------------");
	//iteration can be done in 2 ways in vector	
	Iterator itr=v.iterator();
	while(itr.hasNext()) {
		System.out.println(itr.next());
	}
	System.out.println("-------------------------------------");
	for(Object o:v) {
		System.out.println(o);
	}
	System.out.println(v.contains(11));
	System.out.println(v.isEmpty());
    v.remove(1);
	System.out.println(v);
	System.out.println(v.size());
	
	
}
}
