package com.hw4_4.student;

public class Main {
public static void main(String[] args) {
	Student s=new Student(101,"Manasi","CSE","4th",81);
	s.sDetails();
	s.grade();
}
}
