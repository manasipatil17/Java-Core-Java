package com.hw4_4.student;

public class Student {
// Define a Student class with attributes: studentId, studentName, course, year, percentage.
// Implement a method to display student details.
// Implement a method to calculate the student's grade based on the percentage.
// Create a Main class to test the functionality.

	int sId;
	String sName;
	String course;
	String year;
	int percent;
	
	public Student(int sId, String sName, String course, String year, int percent) {
		this.sId=sId;
		this.sName=sName;
		this.course=course;
		this.year=year;
		this.percent=percent;
	}
	public void sDetails() {
		System.out.println("Stunde ID :"+sId);
		System.out.println("Stunde name :"+sName);
		System.out.println("Stunde course :"+course);
		System.out.println("Stunde class :"+year+" year");
		System.out.println("Stunde percent :"+percent);
	}
	
	public String grade(){
		if(percent>=90 && percent<=100) {
			System.out.println("Grade A");
		}
		else if(percent>=80 && percent<=89) {
			System.out.println("Grade B");
		}
		else if(percent>=70 && percent<=79) {
			System.out.println("Grade C");
		}

		else if(percent>=60 && percent<=69) {
			System.out.println("Grade D");
		}
		else if(percent>=50 && percent<=59) {
			System.out.println("Grade E");
		}
		else if(percent>=35 && percent<=49) {
			System.out.println("PASS");
		}
		else if(percent>=00 && percent<=34) {
			System.out.println("Fail");
		}
		else {
			System.out.println("Enter correct percent");
		}
return "a"; 

	}
}
