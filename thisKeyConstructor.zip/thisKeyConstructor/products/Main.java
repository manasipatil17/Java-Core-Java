package com.hw4_4.products;

	public class Main {
	    public static void main(String[] args) {
	        // Creating a Product object
	        Product product1 = new Product(101, "Laptop", 800.0, 20);
	        Product product2 = new Product(102, "Smartphone", 500.0, 15);

	        // Displaying product details
	        System.out.println("Product 1 Details:");
	        product1.displayProductDetails();
	        System.out.println("Product 2 Details:");
	        product2.displayProductDetails();

	        // Purchasing products
	        System.out.println("Purchasing products...");
	        product1.purchaseProduct(5);  // Buying 5 Laptops
	        product1.purchaseProduct(25); // Trying to buy more than available stock

	        // Adding stock
	        System.out.println("Adding stock...");
	        product1.addStock(10);  // Adding 10 Laptops to stock
	        product2.addStock(5);   // Adding 5 Smartphones to stock

	       
	        System.out.println("Updated Product Details:");
	        product1.displayProductDetails();
	        product2.displayProductDetails();
	    }
	}


