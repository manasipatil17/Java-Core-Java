package com.hw4_4.products;

public class Product {
	    
	    int productId;
	    String productName;
	    double price;
	    int stock;

	    public Product(int productId, String productName, double price, int stock) {
	        this.productId = productId;
	        this.productName = productName;
	        this.price = price;
	        this.stock = stock;
	    }

	  
	    public void displayProductDetails() {
	        System.out.println("Product ID: " + productId);
	        System.out.println("Product Name: " + productName);
	        System.out.println("Price: " + price);
	        System.out.println("Stock: " + stock);
	    }

	    public boolean purchaseProduct(int quantity) {
	        if (quantity > 0 && quantity <= stock) {
	            stock -= quantity;
	            System.out.println("Purchased " + quantity + " of " + productName);
	            return true;
	        } else if (quantity > stock) {
	            System.out.println("Insufficient stock. Available stock: " + stock);
	            return false;
	        } else {
	            System.out.println("Invalid quantity. Quantity must be positive.");
	            return false;
	        }
	    }

	    public void addStock(int quantity) {
	        if (quantity > 0) {
	            stock += quantity;
	            System.out.println("Added " + quantity + " to stock.");
	        } else {
	            System.out.println("Invalid quantity. Quantity must be positive.");
	        }
	    }
	}


