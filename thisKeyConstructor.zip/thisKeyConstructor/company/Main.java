package com.hw4_4.company;

public class Main {
	    public static void main(String[] args) {
	        Employee emp1 = new Employee(101, "Alice Smith", "Software Engineer", 45000);
	        Employee emp2 = new Employee(102, "Bob Johnson", "Project Manager", 60000);

	       
	        System.out.println("Employee 1 Details:");
	        emp1.displayEmployeeDetails();
	        System.out.println("Bonus: " + emp1.calculateBonus());
	        
	        System.out.println("\nEmployee 2 Details:");
	        emp2.displayEmployeeDetails();
	        System.out.println("Bonus: " + emp2.calculateBonus());
	    }
	}


