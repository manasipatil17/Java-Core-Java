package com.hw4_4.company;

public class Employee {
	
	     int empId;
	     String empName;
	     String designation;
	     double salary;

	    public Employee(int empId, String empName, String designation, double salary) {
	        this.empId = empId;
	        this.empName = empName;
	        this.designation = designation;
	        this.salary = salary;
	    }

	    public void displayEmployeeDetails() {
	        System.out.println("Employee ID: " + empId);
	        System.out.println("Employee Name: " + empName);
	        System.out.println("Designation: " + designation);
	        System.out.println("Salary: " + salary);
	    }

	    
	    public double calculateBonus() {
	        if (salary < 50000) {
	            return salary * 0.10; // 10% bonus if salary is less than 50,000
	        } else {
	            return salary * 0.05; // 5% bonus if salary is greater than or equal to 50,000
	        }
	    }
	

}
