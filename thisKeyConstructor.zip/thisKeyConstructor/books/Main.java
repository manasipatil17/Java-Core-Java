package com.hw4_4.books;

public class Main {
	    public static void main(String[] args) {
	       
	        Book book1 = new Book(101, "Java Programming", "John Doe", 29.99, 10);
	        Book book2 = new Book(102, "Data Structures", "Jane Smith", 39.99, 5);

	        // Displaying book details
	        System.out.println("Book 1 Details:");
	        book1.displayBookDetails();
	        System.out.println("Book 2 Details:");
	        book2.displayBookDetails();

	        // Issuing books
	        System.out.println("\nIssuing books...");
	        book1.issueBook(3);   // Issuing 3 copies of "Java Programming"
	        book1.issueBook(8);   // Trying to issue more than available copies
	        book2.issueBook(2);   // Issuing 2 copies of "Data Structures"

	        // Returning books
	        System.out.println("\nReturning books...");
	        book1.returnBook(2);  // Returning 2 copies of "Java Programming"
	        book2.returnBook(1);  // Returning 1 copy of "Data Structures"
	        
	        // Displaying book details again after transactions
	        System.out.println("\nUpdated Book Details:");
	        book1.displayBookDetails();
	        book2.displayBookDetails();
	    }
	}


