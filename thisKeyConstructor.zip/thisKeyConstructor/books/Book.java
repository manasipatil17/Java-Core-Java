package com.hw4_4.books;

public class Book {
	    
	  int bookId;
	  String title;
	  String author;
	  double price;
	  int availableCopies;

	   
	    public Book(int bookId, String title, String author, double price, int availableCopies) {
	        this.bookId = bookId;
	        this.title = title;
	        this.author = author;
	        this.price = price;
	        this.availableCopies = availableCopies;
	    }

	    // Method to display book details
	    public void displayBookDetails() {
	        System.out.println("Book ID: " + bookId);
	        System.out.println("Title: " + title);
	        System.out.println("Author: " + author);
	        System.out.println("Price: " + price);
	        System.out.println("Available Copies: " + availableCopies);
	    }

	    public boolean issueBook(int quantity) {
	        if (quantity > 0 && quantity <= availableCopies) {
	            availableCopies -= quantity;
	            System.out.println("Issued " + quantity + " copy(ies) of " + title);
	            return true;
	        } else if (quantity > availableCopies) {
	            System.out.println("Insufficient copies available. Available copies: " + availableCopies);
	            return false;
	        } else {
	            System.out.println("Invalid quantity. Quantity must be positive.");
	            return false;
	        }
	    }

	    public void returnBook(int quantity) {
	        if (quantity > 0) {
	            availableCopies += quantity;
	            System.out.println("Returned " + quantity + " copy(ies) of " + title);
	        } else {
	            System.out.println("Invalid quantity. Quantity must be positive.");
	        }
	    }
	}


