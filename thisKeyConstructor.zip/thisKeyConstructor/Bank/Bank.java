package com.hw4_4.Bank;

public class Bank {
//2. Define a BankAccount class with attributes: accountNumber, accountHolder, balance.
//	   Implement methods for deposit, withdraw, and displayAccountDetails.
//	   Ensure that withdrawal does not allow balance to go negative.
//	   Create a Main class to test various transactions.
	
    String accountNumber;
    String accountHolder;
    double balance;

    // Constructor
    public Bank(String accountNumber, String accountHolder, double initialBalance) {
        this.accountNumber = accountNumber;
        this.accountHolder = accountHolder;
        this.balance = initialBalance;
    }

    // Method to deposit money
    public void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
            System.out.println("Deposited: " + amount);
        } else {
            System.out.println("Deposit amount must be positive.");
        }
    }

    // Method to withdraw money
    public void withdraw(double amount) {
        if (amount > 0 && amount <= balance) {
            balance -= amount;
            System.out.println("Withdrew: " + amount);
        } else if (amount > balance) {
            System.out.println("Insufficient balance.");
        } else {
            System.out.println("Withdrawal amount must be positive.");
        }
    }

    
    public void displayAccountDetails() {
        System.out.println("Account Number: " + accountNumber);
        System.out.println("Account Holder: " + accountHolder);
        System.out.println("Balance: " + balance);
    }
}


