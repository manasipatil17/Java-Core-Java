package com.hw4_4.Bank;

public class Main {
	public static void main(String[] args) {
       
       Bank account = new Bank("123456789", "John Doe", 1000.0);

        account.displayAccountDetails();

        account.deposit(500);  
        account.withdraw(300); 
        account.withdraw(1500); 
        account.deposit(-100);  
        account.withdraw(-50);  

        account.displayAccountDetails();
    }
}
