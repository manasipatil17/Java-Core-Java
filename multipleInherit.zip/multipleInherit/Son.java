package com.multipleInherit;

public class Son implements Father, Mother{

	@Override
	public void cook() {
		System.out.println("Mother can cook");
		
	}

	@Override
	public void drive() {
		System.out.println("Father can drive vehicle");
		
	}

	public static void main(String[] args) {
		Son s=new Son();
		s.drive();
		System.out.println("---------------------------------");
		s.cook();
	}
}
