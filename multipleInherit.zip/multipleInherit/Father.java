package com.multipleInherit;

public interface Father {
void drive();
}
