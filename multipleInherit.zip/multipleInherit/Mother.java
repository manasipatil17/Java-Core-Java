package com.multipleInherit;

public interface Mother {

	void cook();
}
