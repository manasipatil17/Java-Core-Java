package com.stringPractice;

public class CountNumFromPassword {

	public static void main(String[] args) {
		
		//WAP to accept password of the user and count the number of digits in it. 
		String passward="Manasi@2004";
		int count=0;
		for(int i=0;i<passward.length();i++) {
			if(Character.isDigit(passward.charAt(i))){
				count++;
			}
			
		}
		System.out.println("Total number of digits in passward : "+count);

			}
}
