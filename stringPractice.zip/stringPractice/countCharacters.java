package com.stringPractice;

public class countCharacters {
public static void main(String[] args) {
	
	//WAP to accept name of the user and count the number of characters in it. 
	String userName="Manasi";
	
	int count =userName.trim().length();
	System.out.println("Count of digits :"+count);    
}
}