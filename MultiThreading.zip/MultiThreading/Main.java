package com.MultiThreading;

public class Main {
public static void main(String[] args) {
	AddParticipants a=new AddParticipants();
	a.start();
	Annotate an=new Annotate();
	an.start();
	Audio ad=new Audio();
	Thread t=new Thread(ad);
	t.start();
	ScreenShare sr=new ScreenShare();
	Thread t1=new Thread(sr);
	t1.start();
	Video vd=new Video();
	vd.start();
}
}
