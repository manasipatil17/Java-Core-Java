package com.MultiThreading;

public class AddParticipants extends Thread{
public void p1() {
	for(int i=1;i<=10;i++) {
		System.out.println("Participant "+i+" added");
	}
	
	}
public void run() {
	AddParticipants a=new AddParticipants();
	a.p1();
try {
	Thread.sleep(1000);
} catch (InterruptedException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}
}
}
