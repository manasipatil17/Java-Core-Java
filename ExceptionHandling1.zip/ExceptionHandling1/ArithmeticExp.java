package com.ExceptionHandling1;

import java.util.Scanner;
//Write a Java program that takes two numbers from the user and divides them. Handle the exception 
//if the second number is zero using try-catch-finally.
//🔹 Expected: Catch ArithmeticException, and print a message like “Cannot divide by zero”.

public class ArithmeticExp {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter numerator : ");
		int a = sc.nextInt();
		System.out.println("Enter denominator : ");
		int b = sc.nextInt();
		try {
			int div = a / b;
			System.out.println(div);
		} catch (ArithmeticException e) {
			System.out.println("Exception is : " + e.getMessage());
			System.out.println("Cannot divide by zero");

		}
	}
}
