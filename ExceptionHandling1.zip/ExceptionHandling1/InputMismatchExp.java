package com.ExceptionHandling1;

import java.util.InputMismatchException;
import java.util.Scanner;

//Accept integer input from the user using Scanner. If the user enters a string instead of a 
//number, handle it using try-catch.
//🔹 Catch InputMismatchException.

public class InputMismatchExp {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Number : ");
		try {
		int num=sc.nextInt();
		System.out.println(num);
		}
		catch(InputMismatchException e) {
			System.out.println("integer cannot be string/character/symbol");
		}
		
	}
}
