package com.ExceptionHandling1;

//Write a program that converts a string (e.g., "abc123") to an integer using Integer.parseInt(). 

//Handle any exception that may occur.
//🔹 Catch NumberFormatException and print “Invalid number format”.

public class NumberFormatExp {
	public static void main(String[] args) {
		String s = "abcd1234";
		try {
			Integer.parseInt(s);

		} catch (NumberFormatException e) {
			System.out.println("Invalid number format");
		}
	}
}
