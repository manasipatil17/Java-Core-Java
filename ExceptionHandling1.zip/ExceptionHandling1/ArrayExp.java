package com.ExceptionHandling1;

//Write a Java program that creates an array of 5 elements and tries to access the 10th element.
//Use try-catch-finally to handle any exception.
//🔹 Expected: Catch ArrayIndexOutOfBoundsException.

public class ArrayExp {
	public static void main(String[] args) {

		int arr[] = new int[5];
		try {
			arr[10] = 50;
		} catch (ArrayIndexOutOfBoundsException e) {
			// e.printStackTrace();
			System.out.println("Exception is :" + e.getMessage());
		} finally {
			System.out.println("finally block");
		}
	}
}
