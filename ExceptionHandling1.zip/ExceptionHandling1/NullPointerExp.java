package com.ExceptionHandling1;

//Write a program where you initialize a String to null and try to call .length() on it. 

//Handle the exception using a try-catch-finally block.
//🔹 Expected: Catch NullPointerException.

public class NullPointerExp {
	public static void main(String[] args) {
		String str = null;
		try {
			str.length();
		} catch (NullPointerException e) {
			System.out.println("Exception is : " + e.getMessage());
		} finally {
			System.out.println("finally block always executes");
		}
	}
}
