package com.inheritanceHybrid;

public class Son extends Father {

	public void s1() {
		System.out.println("Method from son class");
	}
}
