package com.inheritanceHybrid;

public class Uncle extends GrandFather{
public void u1() {
	System.out.println("Method from uncle class");
}
}
