package com.inheritanceHybrid;

public class Father extends GrandFather{

	public void f1() {
		System.out.println("Method from father class");
	}
	
	
}
