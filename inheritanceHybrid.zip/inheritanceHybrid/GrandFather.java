package com.inheritanceHybrid;

public class GrandFather {
public void g1() {
	System.out.println("Method from grandfather class");
}
}
