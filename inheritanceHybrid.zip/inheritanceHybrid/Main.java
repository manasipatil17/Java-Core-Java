package com.inheritanceHybrid;

public class Main {
public static void main(String[] args) {
	Father f=new Father();
	f.g1();
	f.f1();
	System.out.println("-------------------------------------");
	
	Uncle u=new Uncle();
	u.g1();
	u.u1();
	System.out.println("-------------------------------------");

	Son s=new Son();
	s.g1();
	s.f1();
	s.s1();
	System.out.println("-------------------------------------");
}
}
