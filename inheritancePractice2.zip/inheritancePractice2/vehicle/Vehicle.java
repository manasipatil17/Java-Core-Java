package com.inheritancePractice2.vehicle;

public class Vehicle {
	void move() {
        System.out.println("Vehicle is moving.");
    }
}
