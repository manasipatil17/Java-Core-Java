package com.inheritancePractice2.vehicle;

public class Car extends Fourwheeler {
	void musicSystem() {
        System.out.println("Car music system is playing.");
    }
	
	public static void main(String[] args) {
		Car c=new Car();
		c.move();
		c.drive();
		c.musicSystem();
	}
}
