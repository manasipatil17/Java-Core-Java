package com.inheritancePractice2.vehicle;

public class Fourwheeler extends Vehicle {

	void drive() {
        System.out.println("Driving a four-wheeler.");
    }
}
