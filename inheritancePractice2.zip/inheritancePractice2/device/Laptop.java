package com.inheritancePractice2.device;

public class Laptop extends Computer{

	void carry() {
        System.out.println("Laptop is being carried.");
    }
	
	public static void main(String[] args) {
		Laptop l=new Laptop();
		l.powerOn();
		l.boot();
		l.carry();;
	}
	
}
