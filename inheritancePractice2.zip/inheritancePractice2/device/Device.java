package com.inheritancePractice2.device;

public class Device {
    void powerOn() {
        System.out.println("Device is powered on.");
    }

}
