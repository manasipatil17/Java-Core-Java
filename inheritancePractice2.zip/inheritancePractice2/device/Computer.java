package com.inheritancePractice2.device;

public class Computer extends Device {

    void boot() {
        System.out.println("Computer is booting up.");
    }
}
