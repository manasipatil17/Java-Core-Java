package com.inheritancePractice2.person;

public class Employee extends Person {

	public void displayEmp() {
		System.out.println("Method from employee class ");
	}
}
