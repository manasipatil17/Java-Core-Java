package com.inheritancePractice2.person;

public class Person {

	public void displayPerson() {
		System.out.println("Method from person class");
	}
}
