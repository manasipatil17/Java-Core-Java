package com.inheritancePractice2.person;

public class Manager extends Employee {

	
	public void displayManager() {
		System.out.println("Method from manager class");
	}
	
	public static void main(String[] args) {
		Manager m=new Manager();
		m.displayPerson();
		m.displayEmp();
		m.displayManager();
	}
}
