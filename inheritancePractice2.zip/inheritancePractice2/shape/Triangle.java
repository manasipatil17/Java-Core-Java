package com.inheritancePractice2.shape;

public class Triangle extends Polygon {
	public void t1() {
		System.out.println("Method from triangle class");
	}
	
	public static void main(String[] args) {
		Triangle t=new Triangle();
		t.s1();
		t.p1();
		t.t1();
	}
}
