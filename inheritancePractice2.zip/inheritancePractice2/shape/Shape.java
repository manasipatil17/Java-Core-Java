package com.inheritancePractice2.shape;

public class Shape {
	public void s1() {
		System.out.println("Method from shape class");
	}
}
