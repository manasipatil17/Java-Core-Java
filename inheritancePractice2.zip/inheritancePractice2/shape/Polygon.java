package com.inheritancePractice2.shape;

public class Polygon extends Shape{

	public void p1() {
		System.out.println("Method from polygon class");
	}
}
