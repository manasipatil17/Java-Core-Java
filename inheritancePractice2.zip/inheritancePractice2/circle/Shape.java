package com.inheritancePractice2.circle;

public class Shape {
	void draw() {
        System.out.println("Drawing a shape.");
    }
}
