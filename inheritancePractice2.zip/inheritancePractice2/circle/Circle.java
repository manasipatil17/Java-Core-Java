package com.inheritancePractice2.circle;

public class Circle extends Shape {
	double radius;

    // Constructor to set radius
    Circle(double r) {
        radius = r;
    }

    void area() {
        double result = Math.PI * radius * radius;
        System.out.println("Area of the circle: " + result);
    }
    
    public static void main(String[] args) {
		Circle c=new Circle(4);
		c.draw();
		c.area();
	}
}
