package com.inheritancePractice2.animal;

public class Animal {
	void eat() {
        System.out.println("Animal is eating.");
    }
}
