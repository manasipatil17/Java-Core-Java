package com.inheritancePractice2.animal;

public class Human extends Mammal{
	void think() {
        System.out.println("Human is thinking.");
    }
	
	public static void main(String[] args) {
		Human h=new Human();
		h.eat();
		h.walk();
		h.think();
	}
}
