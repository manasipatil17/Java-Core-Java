package com.inheritancePractice2.animal;

public class Mammal extends Animal{
	void walk() {
        System.out.println("Mammal is walking.");
    }
}
