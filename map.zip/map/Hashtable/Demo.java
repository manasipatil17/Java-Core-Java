package com.map.Hashtable;

import java.util.Hashtable;
import java.util.Map.Entry;

public class Demo {
public static void main(String[] args) {
 Hashtable<Integer, String> map = new Hashtable<Integer, String>();
 //null values not allowed for both key and value
 map.put(1, "A");
 map.put(3, "B");
 map.put(2, "D");
 map.put(4, "C");
 map.put(5, "A");
 System.out.println(map);
 
 for(Entry<Integer, String> str: map.entrySet() ) {
	 System.out.println(str.getKey()+" = "+str.getValue());
 }
 
 for(Integer i: map.keySet()) {
	 System.out.println(i);
 }
 
 for(String s: map.values()) {
	 System.out.println(s);
 }

}
}
