package com.map.hashmap;

import java.util.HashMap;
import java.util.Map.Entry;

public class Demo {
public static void main(String[] args) {
	HashMap<Integer, String> hm=new HashMap<Integer, String>();
	hm.put(1, "Manasi");
	hm.put(2, "Ma");
	hm.put(3, null);
	hm.put(4, "a");
	hm.put(null, null);
	
	for(Entry<Integer, String> e : hm.entrySet()) {
		System.out.println(e);
	}
}
}
