package com.map.treeMap;
import java.util.Map.Entry;
import java.util.TreeMap;

public class Demo {
public static void main(String[] args) {
	TreeMap<Integer, String> hm=new TreeMap<Integer, String>();
	hm.put(1, "Manasi");
	hm.put(4, "Ma");
	hm.put(3, null);
	hm.put(5, "a");
	hm.put(2, null);
	
	for(Entry<Integer, String> e : hm.entrySet()) {
		System.out.println(e);
	}

}
}
