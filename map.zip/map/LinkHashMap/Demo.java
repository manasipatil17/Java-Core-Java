package com.map.LinkHashMap;

import java.util.LinkedHashMap;
import java.util.Map.Entry;

public class Demo {
public static void main(String[] args) {
	LinkedHashMap<Integer, String> map=new LinkedHashMap<Integer, String>();
	map.put(1, "A");
	map.put(2, "B");
	map.put(3, "C");
	map.put(4, "null");
	map.put(null, "E");
	System.out.println(map);
	
for(Entry<Integer, String> s:map.entrySet()){
		System.out.println(s.getKey()+" = "+s.getValue());
	}
}
}
