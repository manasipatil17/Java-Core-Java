package com.hw7_4.oneToN;

import java.util.Scanner;

public class Main {
public static void main(String[] args) {
	OneToN o=new OneToN();
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter the last digit of series :");
	o.display(sc.nextInt());
}
}
