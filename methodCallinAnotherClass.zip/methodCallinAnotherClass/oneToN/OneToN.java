package com.hw7_4.oneToN;

public class OneToN {

	public void display(int num) {
		for(int i=0;i<=num;i++) {
			System.out.println(i);
		}
	}
}
