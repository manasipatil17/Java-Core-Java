package com.hw7_4.prime;

import java.util.Scanner;

public class Main {
public static void main(String[] args) {
	Prime p=new Prime();
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter a number : ");
	p.prime(sc.nextInt());
	 
}
}
