package com.hw7_4.evenOdd;

public class Logic {

	public void evenOdd(int num) {
		if(num%2==0) {
			System.out.println("Number is even");
		}
		else {
			System.out.println("Number is odd");
		}
	}
}
