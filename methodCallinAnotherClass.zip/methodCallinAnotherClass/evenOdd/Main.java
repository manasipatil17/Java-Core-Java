package com.hw7_4.evenOdd;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Logic l=new Logic();
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a number ");
		l.evenOdd(sc.nextInt());
	}
}
