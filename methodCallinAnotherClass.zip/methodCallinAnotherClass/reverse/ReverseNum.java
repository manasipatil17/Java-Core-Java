package com.hw7_4.reverse;

public class ReverseNum {

	public void reverse(int n) {
		for(int i=n;i>=1;i--) {
			System.out.println(i);
		}
	}
}
