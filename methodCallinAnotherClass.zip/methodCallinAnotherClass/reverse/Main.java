package com.hw7_4.reverse;

import java.util.Scanner;

public class Main {
public static void main(String[] args) {
	ReverseNum r=new ReverseNum();
	Scanner sc=new Scanner(System.in);
	System.out.println("enter number : ");
	r.reverse(sc.nextInt());
}
}
