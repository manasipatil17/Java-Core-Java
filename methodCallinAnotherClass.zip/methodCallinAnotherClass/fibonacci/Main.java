package com.hw7_4.fibonacci;

import java.util.Scanner;

public class Main {
public static void main(String[] args) {
	Fib f=new Fib();
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter the range of series : ");
	f.fobanacci(10);
}
}
