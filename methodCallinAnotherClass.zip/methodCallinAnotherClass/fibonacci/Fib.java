package com.hw7_4.fibonacci;

public class Fib {

	public void fobanacci(int num) {
		int a=0;
		int b=1;
		int c;
		System.out.print(a);
		System.out.print(" "+ b);
		for(int i=1;i<=num;i++) {
			c=a+b;
			System.out.print(" "+c);
			a=b;
			b=c;
		}
	}
}
