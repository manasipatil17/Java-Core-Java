package com.hw7_4.factorial;

import java.util.Scanner;

public class Main {
public static void main(String[] args) {
	Factorial f=new Factorial();
	Scanner sc=new Scanner(System.in);
	
	System.out.println("Enter a number : ");
	f.fact(sc.nextInt());
}
}
