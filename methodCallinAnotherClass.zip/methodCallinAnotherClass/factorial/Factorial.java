package com.hw7_4.factorial;

public class Factorial {

	public void fact(int a) {
		int fact=1;
		for(int i=a;i>=1;i--) {
			fact=fact*i;
		}
		System.out.println("Factorial of "+a+" is "+fact);
	}
}
