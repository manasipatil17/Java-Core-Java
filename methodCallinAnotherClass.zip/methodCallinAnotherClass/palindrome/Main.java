package com.hw7_4.palindrome;

import java.util.Scanner;

public class Main {
public static void main(String[] args) {
	Palindrome p=new Palindrome();
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter a number : ");
	p.pal(sc.nextInt());
}
}
