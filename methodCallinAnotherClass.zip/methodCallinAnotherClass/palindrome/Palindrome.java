package com.hw7_4.palindrome;

public class Palindrome {

	public void pal(int num) {
		int n = num;

		int rem = 0;
		int num2 = 0;
		while (num > 0) {
			rem = num % 10;
			num2 = num2 * 10 + rem;
			num = num / 10;
		}
		if (n == num2) {
			System.out.println("Number is palindrome");
		} else {
			System.out.println("Not Palindrome");
		}

	}
}
