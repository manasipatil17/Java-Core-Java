package com.hw7_4.sumOfDigits;

import java.util.Scanner;

public class Main {
public static void main(String[] args) {
	Number n=new Number();
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter a number : ");
	n.sum(sc.nextInt());
}
}
