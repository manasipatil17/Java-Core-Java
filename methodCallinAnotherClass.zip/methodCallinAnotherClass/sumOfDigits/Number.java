package com.hw7_4.sumOfDigits;

public class Number {
public void sum(int num) {
	int rem;
	int sum=0;
	while(num>0) {
		rem=num%10;
		sum=sum+rem;
		num=num/10;
	}
	System.out.println("sum of digit is "+sum);
}
}
