package com.hw7_4.table;

import java.util.Scanner;

public class Main {

public static void main(String[] args) {
	Table t=new Table();
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a number :");
		t.table(sc.nextInt());
		
		}
}