package com.hw7_4.table;

import java.util.Scanner;

public class Table {
	
public void table(int a) {
	for(int i=1;i<=10;i++) {
		System.out.println(i*a);
		
	}
}
}
