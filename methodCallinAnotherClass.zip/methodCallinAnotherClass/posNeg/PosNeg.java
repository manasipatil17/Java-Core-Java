package com.hw7_4.posNeg;

public class PosNeg {

	public void pos(int a) {
		if(a>0) {
			System.out.println("Given number is positive");
		}
		else if(a<0) {
			System.out.println("Given number is negative");
		}
		else {
			System.out.println("given number is zero");
		}
	}
}
