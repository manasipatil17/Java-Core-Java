package com.hw7_4.posNeg;

import java.util.Scanner;

public class Main {
public static void main(String[] args) {
	PosNeg p=new PosNeg();
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter a number : ");
	p.pos(sc.nextInt());
}
}
