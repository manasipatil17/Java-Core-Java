package com.ifElse;

import java.util.Scanner;

public class ScholarshipEligibility {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	
	System.out.println("Enter marks and income : ");
	int marks=sc.nextInt();
	int incm=sc.nextInt();
	
	if(marks>=90 &&marks<=100 && incm<=70000) {
		System.out.println("Eligible for scholarship");
	}
	else {
		System.out.println("Not eligible for scholarship");
	}
}
}
