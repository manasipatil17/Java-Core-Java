package com.ifElse;

import java.util.Scanner;

public class VowelWith4cases {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter any character : ");
char ch=sc.next().charAt(0);
if(Character.isLetter(ch)) {
if(ch>='a' && ch<='z') {
if(ch=='a'||ch=='e'||ch=='i'||ch=='o'||ch=='u') {
	System.out.println("Lower case vowel");
}
else {
	System.out.println("Lower case consonent");
}
} 
else if(ch>='A' && ch<='Z') {
if(ch=='A'||ch=='E'||ch=='I'||ch=='O'||ch=='U') {
	System.out.println("Upper case vowel");
}else{
		System.out.println("Upper case consonent");
	}
}	
}
}
}
