package com.ifElse;

import java.util.Scanner;

public class LargestOfThreeNo {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	
	System.out.println("Enter three numbers to check which one is largest : ");
    int num1=sc.nextInt();
    int num2=sc.nextInt();
    int num3=sc.nextInt();
   
    if(num1>num2 && num1>num3) {
    	System.out.println(num1+" is largest");
    }
    else if(num1<num2 && num2>num3) {
    	System.out.println(num2+" is largest");
    }
    else {
    	System.out.println(num3+" is largest");
    }
}
}
