package com.ifElse;

import java.util.Scanner;

public class DivBy5and11 {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter any number to check it is divisible by 5 & 11 : ");
	int num=sc.nextInt();
	if(num%5==0 && num%11==0) {
		System.out.println("Number is divisible by both 5 and 11");
	}
	else {
		System.out.println("Number is not divisible by 5 and 11");
	}
}
}
