package com.ifElse;

import java.util.Scanner;

public class TriangleClassification {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter three sides of triangles : ");
	int a=sc.nextInt();
	int b=sc.nextInt();
	int c=sc.nextInt();
	
	if(a==b && b==c) {
		System.out.println("Equilateral");
	}
	else if(a==b ||a==c || b==c) {
		System.out.println("Isosceles");
	}
	else {
		System.out.println("scalene");
	}
}
}
