package com.ifElse;

public class AgeAndGender {
public static void main(String[] args) {
	int age=23;
	char gender='F';
	if(age>21 && gender=='M') {
		System.out.println("Male, Eligible for marriage ");
	}
	else if(age>18 && gender=='F') {
		System.out.println("Female, Eligible for marriage ");
	}
	else {
		System.out.println("Not eligible");
	}
}
}
