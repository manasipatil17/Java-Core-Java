package com.loops2;

public class FactorialOfNum {
public static void main(String[] args) {
	//Find the factorial of a number using a while loop.
   int num=5;
   int fact=1;
   while(num>=1) {
	   fact*=num;
	   num--;
   }
   System.out.println(fact);
}
}
