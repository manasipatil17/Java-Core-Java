package com.loops2;

public class SumOfDigits {

public static void main(String[] args) {
	//Find the sum of digits of a number using a while loop.

	int num=1243;
	int sum=0;
	int rem;
	while(num>0) {
		rem=num%10;
		sum+=rem;
		num=num/10;
	}
	System.out.println(sum);
}
}
