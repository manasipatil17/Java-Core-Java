package com.loops2;

public class SumOfDigitsDoWhile {
public static void main(String[] args) {
	int num=32894;
	int rem;
	int sum=0;
	do {
		rem=num%10;
		sum+=rem;
		num=num/10;
	}while(num>0);
	System.out.println("Sum of digit is "+sum);
}
}
