package com.loops2;

public class CountNoOfDigits {

	public static void main(String[] args) {
		//Count the number of digits in a given number using a while loop.
		
		int num=1230;
		int count=0;
		while(num>0) {
			num=num/10;
			count++;
		}
		System.out.println("Count of digit is  "+count);
	}
}
