package com.loops2;

public class GCD {
public static void main(String[] args) {
	//Find the greatest common divisor (GCD) of two numbers using a while loop.

	int a=10;
	int b=20;
	while(b!=0) {
		int temp=b;
		b=a%b;
		a=temp;
	}
	System.out.println(a);
}
}
