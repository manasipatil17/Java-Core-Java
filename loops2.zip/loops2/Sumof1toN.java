package com.loops2;

public class Sumof1toN {
	//Print the sum of numbers from 1 to N using a while loop.
public static void main(String[] args) {
	int i=1;
	int sum=0;
	while(i<=10) {
		sum+=i;
		i++;
	}
	System.out.println(sum);
}
}
