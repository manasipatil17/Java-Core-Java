package com.loops2;

public class Palindrome {
public static void main(String[] args) {
	//Check if a number is a palindrome using a while loop.

	int num = 43534;
	int n = num;

	int rem = 0;
	int num2 = 0;
	while (num > 0) {
		rem = num % 10;
		num2 = num2 * 10 + rem;
		num = num / 10;
	}
	if (n == num2) {
		System.out.println("Number is palindrome");
	} else {
		System.out.println("Not Palindrome");
	}

}
}
