package com.loops2;

public class SumOf1toNbyDoWhile {
public static void main(String[] args) {
	//Print the sum of numbers from 1 to N using a do-while loop.
int i=1;
int sum=0;
do {
	sum+=i;
	i++;
}while(i<=10);
System.out.println(sum);
}
}
