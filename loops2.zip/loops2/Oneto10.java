package com.loops2;

public class Oneto10 {
public static void main(String[] args) {
	//Print numbers from 1 to 10 using a while loop.

	int i=1;
	while(i<=10) {
		System.out.println(i);
		i++;
	}
}
}
