package com.loops2;

public class SumOfEvenByDo {
public static void main(String[] args) {
	//Find the sum of all even digits in a number using a do-while loop.
	int i=1;
	int sum=0;
	do {
		if(i%2==0) {
			sum+=i;
		}
		i++;
	}while(i<=10);
	System.out.println("sum of even from 1 to 10 is "+sum);
}
}
