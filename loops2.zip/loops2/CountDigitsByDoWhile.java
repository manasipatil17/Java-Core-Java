package com.loops2;

public class CountDigitsByDoWhile {

	public static void main(String[] args) {
		int num=1234;
		int count=0;
		do {
			num=num/10;
			count++;
		}while(num>0);
		System.out.println("count of digits is "+count);
		
	}

}
