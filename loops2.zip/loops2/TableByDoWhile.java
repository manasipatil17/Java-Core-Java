package com.loops2;

public class TableByDoWhile {
public static void main(String[] args) {
	//Print the multiplication table of a given number using a do-while loop.
int i=1;
do {
	System.out.println(12+" * "+i+" = "+12*i);
	i++;
}while(i<=10);
}
}
