package com.loops2;

public class MultiplyTable {
public static void main(String[] args) {
	int i=1;
	while(i<=10) {
		System.out.println(14+" * "+i+" = "+14*i);
		i++;
	}
}
}
