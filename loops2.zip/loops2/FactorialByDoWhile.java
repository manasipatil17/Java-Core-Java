package com.loops2;

public class FactorialByDoWhile {
public static void main(String[] args) {
	//Find the factorial of a number using a do-while loop.

	int num=5;
	int fact=1;
	do {
		fact*=num;
		num--;
	}while(num>=1);
	System.out.println(fact);
}
}
