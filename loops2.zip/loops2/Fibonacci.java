package com.loops2;

public class Fibonacci {
public static void main(String[] args) {
	//Print the Fibonacci series up to N terms using a while loop.

	int a=0;
	int b=1;
	int c;
	int i=1;
	System.out.print(a+" ");
	System.out.print(b+" ");
	while( i<=10) {
		c=a+b;
		System.out.print(c+" ");
		a=b;
		b=c;
		i++;
	}
}
}
