package com.loops2;

public class ReverseNo {
public static void main(String[] args) {
	//Reverse a number using a while loop.

	int i=50;
	while(i>=1) {
		System.out.println(i);
		i--;
	}
}
}
