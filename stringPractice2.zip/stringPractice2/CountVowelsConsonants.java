package com.stringPractice2;

public class CountVowelsConsonants {
//Write a Java program to count the number of vowels and consonants in a string.
public static void main(String[] args) {
	String s="abcdefghij";
	int count=0;
	int consCount=0;
	for(int i=0;i<s.length();i++) {
		char c=s.charAt(i);
		if(c=='a'||c=='e'||c=='i'||c=='o'||c=='u'||c=='A'||c=='E'||c=='I'||c=='O'||c=='U') {
			count++;
		}
		else {
			consCount++;
		}
	}
	System.out.println("String is : "+s );
	System.out.println("number of vowels : "+count);
	System.out.println("number of consonants : "+consCount);
	
}
}