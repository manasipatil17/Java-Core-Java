package com.stringPractice2;

public class CountWords {
public static void main(String[] args) {
	
	//Write a Java program to count the number of words in a string.

	String s="India is my country";
	
      String[] s1=s.trim().split("\\s+");
	
      int count = s1.length;
      System.out.println(count);
//	int count=1;
//	for(int i=0;i<s.length();i++) {
//		char c=s.charAt(i);
//		if(c==' ') {
//			count++;
//		}
//	}
//	System.out.println("String is : "+s);
//	System.out.println("Number of words : "+count);
}
}
