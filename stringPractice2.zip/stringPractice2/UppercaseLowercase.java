package com.stringPractice2;

public class UppercaseLowercase {
//Write a Java program to convert a string to uppercase and lowercase.

	public static void main(String[] args) {
		String s="Manasi";
		System.out.println(s.toUpperCase());
		System.out.println(s.toLowerCase());
	}
}
