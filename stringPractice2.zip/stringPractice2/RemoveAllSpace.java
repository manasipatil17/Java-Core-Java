package com.stringPractice2;

public class RemoveAllSpace {
//Write a Java program to remove all white spaces from a string.

	public static void main(String[] args) {
		String s="  ma na si  ";
		
		String s1=s.replaceAll("\\s+", "");
		
		System.out.println(s);
		System.out.println(s1);
	
		
		
	}
}
