package com.stringPractice2;

public class ReverseString {
//Write a Java program to reverse a string.
public static void main(String[] args) {
	String s="Manasi";
	
	StringBuilder s1=new StringBuilder(s);
    s1.reverse();
    System.out.println(s1);
}
	
}
