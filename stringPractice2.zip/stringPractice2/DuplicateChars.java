package com.stringPractice2;

public class DuplicateChars {
//Write a Java program to find duplicate characters in a string.
	
	public static void main(String[] args) {
		String s1 = "indiaai";
        int count;

        // Convert string to character array
        char[] chars = s1.toCharArray();

        // Boolean array to mark visited characters
        boolean[] visited = new boolean[s1.length()];

        System.out.println("Duplicate characters are:");

        for (int i = 0; i < chars.length; i++) {
            if (visited[i]) continue; // Skip if already checked

            count = 1;

            for (int j = i + 1; j < chars.length; j++) {
                if (chars[i] == chars[j]) {
                    count++;
                    visited[j] = true; // Mark duplicate as visited
                }
            }

            if (count > 1) {
                System.out.println(chars[i] + " -> " + count + " times");
            }
        }
    }}
