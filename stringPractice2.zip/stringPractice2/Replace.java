package com.stringPractice2;

public class Replace {
	//Write a Java program to replace all occurrences of a character with another.

public static void main(String[] args) {
	String s= "satara";
	System.out.println("'a' from satara replaced by 'e' : "+s.replace('a', 'i'));
}
}
