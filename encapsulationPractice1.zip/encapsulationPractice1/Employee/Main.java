package com.encapsulationPractice1.Employee;

public class Main {
public static void main(String[] args) {
	Emp e=new Emp();
	e.setId(101);
	e.setName("Manasi");
	e.setSalary(30000);
	
	System.out.println("Employee Id : "+e.getId());
	System.out.println("Employee name : "+e.getName());
	System.out.println("Employee salary : "+e.getSalary());
}
}
