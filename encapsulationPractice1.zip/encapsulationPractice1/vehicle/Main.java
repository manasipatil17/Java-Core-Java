package com.encapsulationPractice1.vehicle;

public class Main {
public static void main(String[] args) {
	Car c=new Car();
	c.setId(101);
	c.setBrand("Creta");
	c.setPrice(1500000);
	
	System.out.println("Car ID : "+c.getId());
	System.out.println("Brand Name : "+c.getBrand());
	System.out.println("Car Price : "+c.getPrice());
}
}
