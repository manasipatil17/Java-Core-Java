package com.encapsulationPractice1.library;

public class Main {
public static void main(String[] args) {
	Book b=new Book();
	b.setId(1);
	b.setbName("Bhagvat Gita");
	b.setPrice(350);
	System.out.println("Book ID : "+b.getId());
	System.out.println("Book Name : "+b.getbName());
	System.out.println("Book price : "+b.getPrice());
}
}
