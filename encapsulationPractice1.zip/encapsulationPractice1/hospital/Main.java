package com.encapsulationPractice1.hospital;

public class Main {
public static void main(String[] args) {
	Patient p=new Patient();
	p.setpId(101);
	p.setName("Manasi");
	p.setDisease("Fever");
	System.out.println("Patient ID : "+p.getpId());
	System.out.println("Patient Name : "+p.getName());
	System.out.println("Disease : "+p.getDisease());
}
}
