package com.staticMethods;

public class Square {
	//Write a method that takes an integer and prints its square. Call the method using the 
		//class name.
		public static int sqr(int a) {
			int square=a*a;
			System.out.println("square of "+a+" is "+square);
			return square;
		}

	public static void main(String[] args) {
		Square.sqr(12);
	}

}
