package com.staticMethods;

public class ReverseOrd {
	// Write a method that takes an integer N and prints natural numbers from N to 1.
	// Call the method using the class name.

	public static int myNum(int a) {
		int i;
		for ( i = a; i >= 1; i--) {
			System.out.println(i);
		}
		return i;
	}

	public static void main(String[] args) {
		ReverseOrd.myNum(50);
	}

}
