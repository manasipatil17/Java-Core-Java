package com.staticMethods;

import com.logicBuilding.OnetoN;

public class OneToN {
	//Write a method that takes an integer N and prints numbers from 1 to N. 
		//Call the method using the class name.
		
		public static int show(int n) {
			int i;
			for( i=1;i<=n;i++) {
				System.out.println(i);
			}
			return i;
		}

	public static void main(String[] args) {
		OnetoN.show(15);
	}

}
