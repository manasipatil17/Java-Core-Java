package com.staticMethods;


public class Ascii {
	//Write a method that takes a character and prints its ASCII value. 
	//Call the method using the class name.

		public static int myChar(char ch) {
			int as=(int)ch;
			System.out.println("ASCII value of "+ch+" is "+as);
			
			return as;
		}
	public static void main(String[] args) {
		Ascii.myChar('w');
		
	}

}
