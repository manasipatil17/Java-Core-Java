package com.staticMethods;

public class SumOfTwoNum {
	//Write a method that takes two integers as parameters and prints their sum. Call the method using the class name.

		public static int add(int a, int b) {
			int c=a+b;
			System.out.println("Addition of two numbers is "+c);
			return c; 
		}
		
	public static void main(String[] args) {
		SumOfTwoNum.add(12,32);
	}

}
