package com.staticMethods;
public class PositiveNeg {
	// Write a method that takes an integer as a parameter and prints whether it is
	// positive,
	// negative, or zero. Call the method using the class name.

	public static int op(int num) {
		if (num > 0) {
			System.out.println("Given number is positive");
		} else if (num < 0) {
			System.out.println("Given number is negative");
		} else {
			System.out.println("Given number is zero");
		}
		return num;
	}

	public static void main(String[] args) {
		PositiveNeg.op(15);
	}

}
