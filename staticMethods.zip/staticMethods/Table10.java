package com.staticMethods;

public class Table10 {
	//Write a method that takes an integer and prints its multiplication table up to 10.
	//Call the method using the class name.

	public static int table() {
		int i;
		for( i=1;i<=10;i++) {
			System.out.println(i*10);
		}
		return i;
	}
public static void main(String[] args) {
	Table10.table();
}
}
