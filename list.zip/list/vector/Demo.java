package com.list.vector;

import java.util.Enumeration;
import java.util.Iterator;
import java.util.ListIterator;
import java.util.Vector;

public class Demo {
public static void main(String[] args) {
	Vector v=new Vector();
	v.add("Ram");
	v.add(12);
	v.add(13.45);
	v.add('&');
	v.add("Ram");
	v.add(true);

	System.out.println(v);
	System.out.println("-------------------------------------");
	//iterstion can be done in 4 ways in vector
	
	Enumeration e=v.elements();
	while(e.hasMoreElements()) {
		System.out.println(e.nextElement());
	}
	System.out.println("-------------------------------------");
	
	Iterator itr=v.iterator();
	while(itr.hasNext()) {
		System.out.println(itr.next());
	}
	System.out.println("-------------------------------------");
	ListIterator li=v.listIterator();
	while(li.hasNext()) {
		System.out.println(li.next());
	}
	System.out.println("-------------------------------------");
	for(Object o:v) {
		System.out.println(o);
	}
	
	
	System.out.println(v.contains(11));
	System.out.println(v.get(2));
	System.out.println(v.indexOf("ram"));
	System.out.println(v.isEmpty());
    v.remove(1);
	System.out.println(v);
	System.out.println(v.size());
	System.out.println(v.getLast());
	System.out.println(v.getFirst());
	v.set(1, "ram");
	System.out.println(v);
}
}
