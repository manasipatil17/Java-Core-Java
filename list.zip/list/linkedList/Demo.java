package com.list.linkedList;

import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.ListIterator;

public class Demo {
	public static void main(String[] args) {
		LinkedList v=new LinkedList();
		v.add("Ram");
		v.add(12);
		v.add(13.45);
		v.add('&');
		v.add("Ram");
		v.add(true);

		System.out.println(v);
		System.out.println("-------------------------------------");
		//iterstion can be done in 3 ways in vector	
		Iterator itr=v.iterator();
		while(itr.hasNext()) {
			System.out.println(itr.next());
		}
		System.out.println("-------------------------------------");
		ListIterator li=v.listIterator();
		while(li.hasNext()) {
			System.out.println(li.next());
		}
		System.out.println("-------------------------------------");
		for(Object o:v) {
			System.out.println(o);
		}
		System.out.println(v.contains(11));
		System.out.println(v.get(2));
		System.out.println(v.indexOf("ram"));
		System.out.println(v.isEmpty());
	    v.remove(1);
		System.out.println(v);
		System.out.println(v.size());
		System.out.println(v.getLast());
		System.out.println(v.getFirst());
		v.set(1, "ram");
		System.out.println(v);
		
		
	}
	}

