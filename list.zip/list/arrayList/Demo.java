package com.list.arrayList;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.ListIterator;

public class Demo {
public static void main(String[] args) {
	
	ArrayList list=new ArrayList();

	list.add(11);
	list.add(23);
	list.add("Ram");
	list.add(true);
	list.add(11);
	
	System.out.println(list);
	System.out.println(list.contains(11));
	System.out.println(list.get(2));
	System.out.println(list.indexOf(11));
	System.out.println(list.isEmpty());
    list.remove(1);
	System.out.println(list);
	System.out.println(list.size());
	System.out.println(list.getLast());
	System.out.println(list.getFirst());
	list.set(1, "ram");
	System.out.println(list);
	
	//<> generics - gives restrictions for datatypes
ArrayList<Integer> list1=new ArrayList<Integer>();
	
	list1.add(11);
	list1.add(23);
	list1.add(11);
	
	
	
	//three way of iterating data from arrayList
	System.out.println("------------------------------------------");
	Iterator itr=list.iterator();
	while(itr.hasNext()) {
		System.out.println(itr.next());
	}
	
	System.out.println("------------------------------------------");
	for(Object l:list) {
		System.out.println(l);
	}
	
	System.out.println("------------------------------------------");
	
	ListIterator li=list.listIterator();
	while(li.hasNext()) {
		System.out.println(li.next());
	}
}
}
