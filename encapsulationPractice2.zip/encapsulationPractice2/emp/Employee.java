package com.encapsulationPractice2.emp;

public class Employee {
//	Create a class Employee with fields: empId, empName, salary.
//	Use getter and setter methods.
//	If salary is set below 10,000, it should display a warning message.

	private int empId;
	private String empName;
	private double salary;
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		if(salary<10000) {
			System.out.println("Salary is less than 10,000");
		}
		else {
		this.salary = salary;
		}
	}
	
	
}
