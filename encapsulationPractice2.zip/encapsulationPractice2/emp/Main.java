package com.encapsulationPractice2.emp;

public class Main {
public static void main(String[] args) {
	Employee e=new Employee();
	
	e.setEmpId(101);
	e.setEmpName("Manasi");
	e.setSalary(19000);
	System.out.println("Employee ID : "+e.getEmpId());
	System.out.println("Employee Name : "+e.getEmpName());
	System.out.println("Employee Salary : "+e.getSalary());
}
}
