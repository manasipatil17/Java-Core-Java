package com.encapsulationPractice2.car;

public class Car {
//	Create a class Car with fields: model, year, and price.
//	Ensure price cannot be set below zero.
//	Create a method to display car details.

	private String model;
	private int year;
	private int price;
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		if(price >0) {
		this.price = price;
		}
	}
	
	public void showDetails() {
		System.out.println("Car model : "+getModel());
		System.out.println("Car year : "+getYear());
		System.out.println("Car price : "+getPrice());
	}
}
