package com.encapsulationPractice2.car;

public class Main {
public static void main(String[] args) {
	Car c=new Car();
	c.setModel("Creata");
	c.setYear(2020);
	c.setPrice(1200000);
	c.showDetails();
}
}
