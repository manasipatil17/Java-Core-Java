package com.encapsulationPractice2.student;

public class Student {
//	Create a class Student with private fields: id, name, and marks.
//	Provide public getter and setter methods.
//In the main class, create a Student object, set values using setters, and display them using getters.
		private int id;
		private String name;
		private double marks;
		public int getId() {
			return id;
		}
		public void setId(int id) {
			this.id = id;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public double getMarks() {
			return marks;
		}
		public void setMarks(double marks) {
			this.marks = marks;
		}
		
		
	}


