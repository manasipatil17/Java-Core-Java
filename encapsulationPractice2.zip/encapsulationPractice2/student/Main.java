package com.encapsulationPractice2.student;

public class Main {
		public static void main(String[] args) {
		Student s=new Student();
		s.setId(101);
		s.setName("Manasi");
		s.setMarks(81);
		System.out.println("Student ID : "+s.getId());	
		System.out.println("Student Name : "+s.getName());
		System.out.println("Student Percent : "+s.getMarks());
	}
	}


