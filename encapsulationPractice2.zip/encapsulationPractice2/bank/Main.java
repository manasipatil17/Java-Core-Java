package com.encapsulationPractice2.bank;

public class Main {
public static void main(String[] args) {
	Bank b=new Bank();
	b.setAccountNumber(1234);
	b.setAccHolderName("Manasi");
	b.setBalance(20000);
	System.out.println("Account No : "+b.getAccountNumber());
	System.out.println("Account Holder : "+b.getAccHolderName());
	System.out.println("Current Balance : "+b.getBalance());
	b.deposit(2000);
	b.showBalance();
	b.withdraw(3000);
	b.showBalance();
}
}
