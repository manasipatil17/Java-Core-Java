package com.encapsulationPractice2.bank;

public class Bank {
//	Create a class BankAccount with private fields: accountNumber, accountHolderName, and balance.
//	Provide public methods to deposit, withdraw, and get balance.
//	Ensure that the balance cannot be set to a negative value.
	
	private int accountNumber;
	private String AccHolderName;
	private double balance;
	
	public int getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getAccHolderName() {
		return AccHolderName;
	}
	public void setAccHolderName(String accHolderName) {
		AccHolderName = accHolderName;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		if(balance>0) {
		this.balance = balance;
		}
		else {
			System.out.println("Balance should be more than 0");
		}
	}
  
	public void deposit(double amount) {
		if(amount>0) {
		balance+=amount;
		System.out.println("Deposited : "+amount);
		}	
		else {
			System.out.println("Deposited amount must be positive");
		}
	}
	
	public void withdraw(double amount) {
		if(amount >0 && amount<=balance) {
			balance-=amount;
			System.out.println("Withdrew : "+amount);
		}
		else{
			System.out.println("Enter correct amount");
		}
	}
	
	public void showBalance() {
		System.out.println("Current balance : "+balance);
	}
}
