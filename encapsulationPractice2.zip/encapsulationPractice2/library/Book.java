package com.encapsulationPractice2.library;

public class Book {
//	Create a class Book with private fields: bookId, title, author, price.
//	Use getter and setter methods to access data.
//	Prevent price from being set if it's less than 100.
	
	private int bookId;
	private String title;
	private String author;
	private double price;
	public int getBookId() {
		return bookId;
	}
	public void setBookId(int bookId) {
		this.bookId = bookId;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
        if (price >= 100) {
            this.price = price;
        } else {
            System.out.println("Price must be at least 100. Price not set.");
        }
    }
}
