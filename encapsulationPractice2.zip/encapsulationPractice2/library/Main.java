package com.encapsulationPractice2.library;

public class Main {
public static void main(String[] args) {
	Book b=new Book();
	b.setBookId(1001);
	b.setTitle("Journey of life");
	b.setAuthor("Manasi");
	b.setPrice(900);
	System.out.println(b.getBookId());
	System.out.println(b.getTitle());
	System.out.println(b.getAuthor());
	System.out.println(b.getPrice());
}
}
