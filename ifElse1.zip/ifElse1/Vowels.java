package com.ifElse1;

	public class Vowels {
	public static void main(String[] args) {
		char val='b';
		if(val=='a'||val=='e'||val=='i'||val=='o'||val=='u') {
			System.out.println("Given value is vowel");
		}
		else {
			System.out.println("value is consonant");
		}
	}
	}


