package com.ifElse1;

	public class ValidInvalid {
		public static void main(String[] args) {
			int num=11;
			if(num<20) {
				System.out.println("Number is valid");
			}
			else {
				System.out.println("number is not valid");
			}
		}}


