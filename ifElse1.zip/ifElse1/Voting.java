package com.ifElse1;

	import java.util.Scanner;

	public class Voting {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter your age : ");
		int age=sc.nextInt();
		if(age>=18) {
			if(age<=150) {
				System.out.println("Candidate is eligible for voting");
			}
			else {
				System.out.println("Candidate is not eligible for voting");
			}
		}
		else {
			System.out.println("Candidate is not eligible for voting");
		}
	}
	}


