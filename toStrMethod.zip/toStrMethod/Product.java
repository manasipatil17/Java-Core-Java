package com.toStrMethod;

public class Product {
	//Create a Product class with a parameterized constructor that initializes productId, productName, 
	//and price. Display the product details.

		int pID;
		String pName; 
		int price;
		public Product(int pID, String pName, int price) {
			this.pID=pID;
			this.pName=pName;
			this.price=price;
		}
		
		@Override
		public String toString() {
			return "Product [pID=" + pID + ", pName=" + pName + ", price=" + price + "]";
		}

		public static void main(String[] args) {
			Product p=new Product(101, "watch", 3500);
			System.out.println(p);
		}

}
