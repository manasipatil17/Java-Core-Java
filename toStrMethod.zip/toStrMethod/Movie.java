package com.toStrMethod;

public class Movie {
//Write a Java program to create a Movie class with a parameterized constructor for movieName, 
//genre, and rating. Display movie details.

	String movieName;
	String genre;
	int rating;
	public Movie(String movieName,String genre,int rating) {
		this.movieName=movieName;
		this.genre=genre;
		this.rating=rating;
	}
	@Override
	public String toString() {
		return "Movie [movieName=" + movieName + ", genre=" + genre + ", rating=" + rating + "]";
	}
	public static void main(String[] args) {
		Movie m=new Movie("Inception","Sci-Fi",9);
		System.out.println(m);
	}
}
