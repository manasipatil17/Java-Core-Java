package com.toStrMethod;

public class Emp {
	//Define an Employee class with a parameterized constructor that accepts id, name, and salary.
	//Print the employee details.
		
		int id;
		String name; 
		String salary;
		public Emp(int id, String name, String salary) {
			this.id=id;
			this.name=name;
			this.salary=salary;
		}
		
		@Override
		public String toString() {
			return "Emp [id=" + id + ", name=" + name + ", salary=" + salary + "]";
		}
		
	public static void main(String[] args) {
				Emp e=new Emp(1,"manasi","20000");
				System.out.println(e);
		}

}
