package com.toStrMethod;

public class Mobile {
//Create a Mobile class with a parameterized constructor that initializes brand, model, and price.
	//Display mobile details.
	String brand;
	String model;
	int price;
	public Mobile(String brand, String model, int price) {
		this.brand=brand;
		this.model=model;
		this.price=price;
	}
	@Override
	public String toString() {
		return "Mobile [brand=" + brand + ", model=" + model + ", price=" + price + "]";
	}
	public static void main(String[] args) {
		Mobile m=new Mobile("OPPO", "OPPO A54", 15000);
		System.out.println(m);
	}
}
