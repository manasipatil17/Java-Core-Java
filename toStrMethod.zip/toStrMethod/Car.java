package com.toStrMethod;

public class Car {
//Write a Java program to create a Car class with a parameterized constructor to initialize brand,
//model, and price. Display car details.

	String brand;
	String model;
	String price;
	
	public Car(String brand, String model, String price) {
		this.brand=brand;
		this.model=model;
		this.price=price;
	}
	
	@Override
	public String toString() {
		return "Car [brand=" + brand + ", model=" + model + ", price=" + price + "]";
	}

	static void main(String[] args) {
		Car c= new Car( "Kia","Seltos","11.3 Lakhs");
		System.out.println(c);
		
	}
}
