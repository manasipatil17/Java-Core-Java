package com.toStrMethod;

public class Laptop {
//Design a Laptop class with a parameterized constructor to initialize brand, ram, and storage.
	//Print the laptop details.
	
	String brand;
	String ram; 
	String storage;
	public Laptop(String brand, String ram, String storage) {
		this.brand=brand;
		this.ram=ram;
		this.storage=storage;
	}
	@Override
	public String toString() {
		return "Laptop [brand=" + brand + ", ram=" + ram + ", storage=" + storage + "]";
	}
	public static void main(String[] args) {
		Laptop l=new Laptop("DELL","16GB","500GB");
		System.out.println(l);
	}

}
