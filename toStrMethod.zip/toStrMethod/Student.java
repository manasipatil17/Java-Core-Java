package com.toStrMethod;

public class Student {
	//Create a Student class with a parameterized constructor to initialize name and age, then
		//create an object and display the values
		String name;
		int age;
		
		public Student(String name, int age) {
			this.name=name;
			this.age=age;
		}

		public String toString() {
			return "Student [name=" + name + ", age=" + age + "]";
		}
		
		public static void main(String[] args) {
			Student s=new Student("Manasi", 20);
			System.out.println(s);
			
		}

}
