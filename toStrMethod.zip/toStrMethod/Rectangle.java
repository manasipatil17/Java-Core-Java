package com.toStrMethod;

public class Rectangle {
//Create a Rectangle class with a parameterized constructor that takes length and width as 
	//parameters. Calculate and display the area.
	
	int length;
	int width;
	public Rectangle(int length, int width) {
		this.length=length;
		this.width=width;
		System.out.println("Area of rectangle is: "+length*width);
		
	}
	@Override
	public String toString() {
		return "Rectangle [length=" + length + ", width=" + width + "]";
	}
 public static void main(String[] args) {
	Rectangle r=new Rectangle(22,12);
	System.out.println(r);
}

}
