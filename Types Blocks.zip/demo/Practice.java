package com.demo;

public class Practice {
int s=12;
static int v=34;
	Practice(){
		System.out.println("This is constructor");
	}
	
	static {
	System.out.println("This is static block");
}
	static{
		System.out.println("Static block 2,");
	}
{
	System.out.println("This is non-static block");
}

    public static void m1() {
    	System.out.println("This is static method");
    	System.out.println(v);
    	Practice p=new Practice();
    	System.out.println(p.s);
    }
    public void m2() {
    	System.out.println("This is non-static method");
    }
public static void main(String[] args) {
	Practice.m1();
	Practice p=new Practice();
	p.m2();
}

}
