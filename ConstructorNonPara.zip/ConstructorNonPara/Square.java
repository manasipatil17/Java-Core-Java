package com.nonPara;

public class Square {
public Square() {
	int a=12;
	int b=a*a;
	System.out.println(b);
}
public static void main(String[] args) {
	Square s=new Square();

}
}
