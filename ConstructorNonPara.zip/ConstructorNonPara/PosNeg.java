package com.nonPara;

public class PosNeg {
	public PosNeg() {
		int n=-12;
		if(n>0) {
			System.out.println("Positive number");
		}
		else if(n<0) {
			System.out.println("Negative number");
		}
		else {
			System.out.println("Zero");
		}
	}
public static void main(String[] args) {
PosNeg p=new PosNeg();	
}
}
