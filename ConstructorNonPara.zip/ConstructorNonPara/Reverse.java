package com.nonPara;

public class Reverse {

	public Reverse() {
		int num=12345;
		int n=num;
		int rem;
		int add=0;
		while(num>0) {
			rem=num%10;
			add=add*10+rem;
			num=num/10;
		}
		System.out.println("Reverse number of "+n+" is "+add);
	}
	public static void main(String[] args) {
		Reverse r=new Reverse();
	}
}
