package com.inheritancePractice3.person;

public class Main {
public static void main(String[] args) {
	Emp e=new Emp();
	e.info();
	e.eInfo();
	Student s=new Student();
	s.info();
	s.sInfo();
}
}
