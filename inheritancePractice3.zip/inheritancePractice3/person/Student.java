package com.inheritancePractice3.person;

public class Student extends Person {

	public void sInfo() {
		System.out.println("Student name is Manasi");
	}
}
