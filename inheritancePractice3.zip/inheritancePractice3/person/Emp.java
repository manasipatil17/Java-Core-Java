package com.inheritancePractice3.person;

public class Emp extends Person{

	public void eInfo() {
		System.out.println("Employee name is Ram");
	}
}
