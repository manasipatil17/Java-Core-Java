package com.inheritancePractice3.person;

public class Person {

	public void info() {
		System.out.println("Person have name : ");
	}
}
