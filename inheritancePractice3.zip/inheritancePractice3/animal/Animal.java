package com.inheritancePractice3.animal;

public class Animal {
//	Create a class Animal with a method makeSound(). Inherit it into a Dog class and override
//	the method to print "Dog barks".
	
	public void makeSound() {
		System.out.println("Animal makes sound");
	}
}
