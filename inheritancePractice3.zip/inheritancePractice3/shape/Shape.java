package com.inheritancePractice3.shape;

public class Shape {
//3.Write a program where a class Shape is inherited by Circle, Rectangle, and Triangle. 
//Each subclass should have a method to calculate area.
	public void area() {
        System.out.println("Calculating area...");
    }
}
