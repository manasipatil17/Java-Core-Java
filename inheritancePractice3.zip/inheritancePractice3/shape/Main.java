package com.inheritancePractice3.shape;

public class Main {

	public static void main(String[] args) {
		Circle c=new Circle();
		c.area();
		c.cArea(12);
		Triangle t=new Triangle();
		t.area();
		t.tArea(10, 6);
		Rectangle r=new Rectangle();
		r.area();
		r.rArea(12, 55);
	}
}
