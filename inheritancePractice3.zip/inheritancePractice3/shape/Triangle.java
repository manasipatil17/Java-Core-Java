package com.inheritancePractice3.shape;

public class Triangle extends Shape{

	public void tArea(double base, double height) {
		double area=0.5*base*height;
		
		System.out.println("Area of triangle is "+area);
	}
}
