package com.inheritancePractice3.shape;

public class Circle extends Shape{

	public void cArea(double r) {
		double area=3.14 * r*r;
		System.out.println("Area of circle is "+area);
	}
}
