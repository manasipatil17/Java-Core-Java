package com.inheritancePractice3.shape;

public class Rectangle extends Shape {

	public void rArea(int l,int b) {
		System.out.println("Area of rectangle is "+l*b);
	}
}
