package com.inheritancePractice3.family;

public class Son extends Father{


	public void showSon() {
		System.out.println("Method from son");
	}

	public static void main(String[] args) {
		Son s=new Son();
		
		s.showGrandfa();
		s.showFather();
		s.showSon();
	}
}
