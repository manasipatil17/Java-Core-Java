package com.inheritancePractice3.family;

public class Father extends GrandFather{

	public void showFather() {
		System.out.println("Method from father");
	}

}
