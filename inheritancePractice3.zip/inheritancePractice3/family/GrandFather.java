package com.inheritancePractice3.family;

public class GrandFather {
//Create a class Grandfather with method showGrandfather(). Inherit it into Father class with method 
//showFather(), and then into Son class with method showSon(). Call all three methods from Son class
//object.

	
	public void showGrandfa() {
		System.out.println("Method from grandfather");
	}
}
