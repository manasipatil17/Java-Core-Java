package com.staticKeyword;

public class EmpDetails {
public static void main(String[] args) {
	Emp e=new Emp(101, "Manasi");
	Emp e1=new Emp(102, "Ram");
	Emp e2=new Emp(103, "Om");
	e.display();
	e1.display();
	e2.display();
}
}
