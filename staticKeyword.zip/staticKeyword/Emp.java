package com.staticKeyword;

public class Emp {
public int id;
public String name;
public static String company="TCS";

public Emp(int id, String name) {
	this.id=id;
	this.name=name;
}
public void display() {
	System.out.println(id+" "+name+" "+company);
}
}
