package com.switchC;

import java.util.Scanner;

public class Vehicles {
public static void main(String[] args) {
	/*Create a program where the user enters the number of wheels (2, 3, 4, 6)
	 *  and displays the type of vehicle (Bike, Auto-Rickshaw, Car, Truck).
	 */
	Scanner sc= new Scanner(System.in);
	System.out.println("ENTER NUMBER OF WHEELS BETWEEN 2, 3, 4, 6 TO CHECK VEHICLE:");

     int btn= sc.nextInt();
	switch(btn) {
	case 2 : 
		System.out.println("Bike");
		break;
	case 3 :
		System.out.println("Auto-Rickshaw...");
		break;
	case 4 :
		System.out.println("Car...");
		break;
	case 6 :
		System.out.println("Truck...");
		break;
	default :
		System.out.println("Enter correct number of wheels");

}
}
}
