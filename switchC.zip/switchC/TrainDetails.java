package com.switchC;

import java.util.Scanner;

public class TrainDetails {
public static void main(String[] args) {
	/*Take the class type (1: General, 2: Sleeper, 3: AC) as input and print the fare
	 *  details for each class.
	 */
	
	Scanner sc= new Scanner(System.in);
	System.out.println("ENTER ANY BUTTON 1 2 3 :");
	System.out.println("1 : To check General class details");
	System.out.println("2 : To check Sleeper class details");
	System.out.println("3 : To check AC class details");
	
     int btn= sc.nextInt();
	switch(btn) {
	case 1 : 
		System.out.println("General Class: ₹500");
		break;
	case 2 :
		System.out.println("Sleeper Class: ₹700");
		break;
	case 3 :
		System.out.println("AC Class: ₹1500");
		break;
	default:
		System.out.println("Enter correct button...");
}
}
}