package com.switchC;

import java.util.Scanner;

public class Recharge {
public static void main(String[] args) {
	/*Implement a menu-driven program where the user selects a recharge plan 
	 * (1: Data Plan, 2: Talktime Plan, 3: SMS Pack) and displays the price accordingly.
	 */
	Scanner sc=new Scanner(System.in);
	System.out.println("To check Data Plan enter 1");
	System.out.println("To check Talktime Plan enter 2");
	System.out.println("To check SMS Pack enter 3");
	
	int btn=sc.nextInt();
	switch(btn) {
	case 1: 
		System.out.println("Data Plan...S");
		break;
	case 2: 
		System.out.println("Talktime Plan...");
		break;
	case 3: 
		System.out.println("SMS Pack...");
		break;
	default :
		System.out.println("Invalid button...");
	}



}
}
