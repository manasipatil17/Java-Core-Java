package com.switchC;

import java.util.Scanner;

public class GameLevels {
public static void main(String[] args) {
	/*Implement a game system where a user selects a difficulty level 
	 * (1: Easy, 2: Medium, 3: Hard) and prints a message accordingly.
	 */
	Scanner sc= new Scanner(System.in);
	System.out.println("ENTER ANY BUTTON 1 2 3 :");
	System.out.println("1 : To choose easy level");
	System.out.println("2 : To choose medium level");
	System.out.println("3 : To choose hard level");
	
     int btn= sc.nextInt();
	switch(btn){
	case 1 : 
		System.out.println("Easy level...");
		break;
	case 2 :
		System.out.println("Medium level...");
		break;
	case 3 :
		System.out.println("Hard level...");
		break;
	default:
		System.out.println("Enter correct button...");

}
}
}