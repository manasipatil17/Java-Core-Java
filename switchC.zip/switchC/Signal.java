package com.switchC;

public class Signal {
public static void main(String[] args) {
	/*
	 * Write a program that takes a color (Red, Yellow, Green) as input and prints the 
	 * corresponding action (Stop, Slow Down, Go).
	 */
	
	String clr = "red";
	switch(clr) {
	case "red" : 
		System.out.println("Stop...");
		break;
	case "Yellow" :
		System.out.println("Slow down...");
		break;
	case "Green" :
		System.out.println("Go...");
		break;
	default:
		System.out.println("Enter correct colour...");
	}
	
}
}
