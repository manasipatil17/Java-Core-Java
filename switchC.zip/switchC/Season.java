package com.switchC;

import java.util.Scanner;

public class Season {
public static void main(String[] args) {
/*Take a season (1: Summer, 2: Winter, 3: Rainy) as input and print the appropriate
 *  advisory message (Stay Hydrated, Wear Warm Clothes, Carry an Umbrella).
 */
	Scanner sc= new Scanner(System.in);
	System.out.println("Enter button to take advice season vise :");
	System.out.println("1 : To choose Summer");
	System.out.println("2 : To choose Winter");
	System.out.println("3 : To choose Rainy");
	
     int btn= sc.nextInt();
	switch(btn) {
	case 1 : 
		System.out.println("Stay Hydrated");
		break;
	case 2 :
		System.out.println("Wear Warm Clothes");
		break;
	case 3 :
		System.out.println("Carry an Umbrella");
		break;
	default:
		System.out.println("Enter correct button...");

}
}
}
