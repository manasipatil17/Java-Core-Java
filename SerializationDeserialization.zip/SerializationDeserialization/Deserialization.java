package com.SerializationDeserialization;

import java.io.FileInputStream;
import java.io.ObjectInputStream;

public class Deserialization{
	// De-serialization process  // read data / get data / fetch data
	
		public static void main(String[] args) throws Exception {
			
			FileInputStream f = new FileInputStream("D:\\data.txt");
			ObjectInputStream o = new ObjectInputStream(f);	
			
			Bird b = (Bird) o.readObject();   // type Casting 
			
			System.out.println(b.name);
			System.out.println(b.color);
			System.out.println(b.age);
			
		}
}
