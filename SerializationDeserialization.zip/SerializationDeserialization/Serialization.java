package com.SerializationDeserialization;

import java.io.FileOutputStream;
import java.io.ObjectOutputStream;

public class Serialization {
public static void main(String[] args) throws Exception {
		
		
		// Serialization process   write operation // insert operation  
		
		Bird b = new Bird();
		
		b.name="parrot";
		b.color="green";
		b.age=5;

		FileOutputStream f = new FileOutputStream("D:\\data.txt");
		ObjectOutputStream o = new ObjectOutputStream(f);
		
		o.writeObject(b);
		
		System.out.println("Object Serialized...!");
		
}
}
