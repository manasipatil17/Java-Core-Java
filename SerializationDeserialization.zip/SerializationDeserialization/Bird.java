package com.SerializationDeserialization;

import java.io.Serializable;

public class Bird  implements Serializable{
	public String name;
	public String color;
	public transient int age;


}
