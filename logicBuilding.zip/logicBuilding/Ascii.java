package com.logicBuilding;

public class Ascii {

	//Write a method that takes a character and prints its ASCII value. 
//Call the method using the class name.

	public static void myChar(char ch) {
		int ascii=(int)ch;
		System.out.println("ASCII value of "+ch+" is "+ascii);
	}
public static void main(String[] args) {
	Ascii.myChar('w');
}
}
