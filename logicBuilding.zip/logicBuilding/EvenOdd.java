package com.logicBuilding;

public class EvenOdd {
//Write a method that takes an integer as a parameter and prints whether it is even or odd. Call the method using the class name.
      public static void op(int a) {
    	  if(a%2==0) {
    		  System.out.println("Number is even");
    	  }
    	  else {
    		  System.out.println("Number is odd");
    	  }
      }
	public static void main(String[] args) {
		EvenOdd.op(12);
	}
}
