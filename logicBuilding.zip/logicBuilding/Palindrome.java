package com.logicBuilding;

public class Palindrome {
//Write a method that takes an integer and prints its reverse. Call the method using the class name.

	public static void reverse(int a) {
		int rem;
		int total=0;
		while(a>0) {
			rem=a%10;
			total=total*10+rem;
			a=a/10;
		}
		System.out.println("reverse number of "+a+" is "+total);
	}
	public static void main(String[] args) {
		Palindrome.reverse(12324);
	}
}
