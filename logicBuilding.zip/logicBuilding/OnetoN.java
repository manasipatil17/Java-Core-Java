package com.logicBuilding;

public class OnetoN {
	//Write a method that takes an integer N and prints numbers from 1 to N. 
	//Call the method using the class name.
	
	public static void show(int n) {
		for(int i=1;i<=n;i++) {
			System.out.println(i);
		}
	}

public static void main(String[] args) {
	OnetoN.show(15);
}
}
