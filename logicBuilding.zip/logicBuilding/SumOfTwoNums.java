package com.logicBuilding;

public class SumOfTwoNums {
//Write a method that takes two integers as parameters and prints their sum. Call the method using the class name.

	public static void add(int a, int b) {
		int c=a+b;
		System.out.println("Addition of two numbers is "+c);
	}
	
public static void main(String[] args) {
	SumOfTwoNums.add(12,32);
}
}
