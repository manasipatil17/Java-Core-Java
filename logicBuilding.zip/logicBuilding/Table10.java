package com.logicBuilding;

public abstract class Table10 {
	//Write a method that takes an integer and prints its multiplication table up to 10.
	//Call the method using the class name.

	public static void table() {
		for(int i=1;i<=10;i++) {
			System.out.println(i*10);
		}
	}
public static void main(String[] args) {
	Table10.table();
}
}
