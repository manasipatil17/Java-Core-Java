package com.logicBuilding;

public class Square {
	//Write a method that takes an integer and prints its square. Call the method using the 
	//class name.
	public static void sqr(int a) {
		int square=a*a;
		System.out.println("square of "+a+" is "+square);
	}

public static void main(String[] args) {
	Square.sqr(12);
}
}
