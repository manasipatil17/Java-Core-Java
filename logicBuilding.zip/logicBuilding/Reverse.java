package com.logicBuilding;

public class Reverse {
	//Write a method that takes an integer N and prints natural numbers from N to 1.
	//Call the method using the class name.

	public static void myNum(int a) {
		for(int i=a;i>=1;i--) {
			System.out.println(i);
		}
	}
public static void main(String[] args) {
	Reverse.myNum(50);
}
}
