package com.logicBuilding;

public class VowelConsonent {
//Write a method that takes a character and prints whether it is a vowel or consonant. 
	//Call the method using the class name.\
	public static void op(char ch) {
		if(ch=='a'||ch=='e'||ch=='i'||ch=='o'||ch=='u'||ch=='A'|ch=='E'||ch=='I'||ch=='O'||ch=='U') {
			System.out.println("Vowel");
		}
		else {
			System.out.println("Consonant");
		}
	}
	
	public static void main(String[] args) {
		VowelConsonent.op('d');
	}
}
