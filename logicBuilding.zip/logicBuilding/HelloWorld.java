package com.logicBuilding;

public class HelloWorld {
	//Write a method that prints "Hello, World!" when called. Call the method using the class name.

	public static void show() {
		System.out.println("Hello World");
	}
public static void main(String[] args) {
	HelloWorld.show();
}
}
