package com.logicBuilding;

public class Cube {
//Write a method that takes an integer and prints its cube. Call the method using the class name.

	public static void cube(int a) {
		int cu=a*a*a;
		System.out.println("Cube of "+a+" is "+cu );
	}
	public static void main(String[] args) {
		Cube.cube(3);
	}
}
