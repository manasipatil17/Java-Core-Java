package com.logicBuilding;

public class Swap {
	//Write a method that takes two numbers as parameters and swaps them without returning anything.
	//Call the method using the class name.
	
	public static void show(int a, int b) {
		b= b+a;
		a=b-a;
		b=b-a;
		System.out.println(a);
		System.out.println(b);
	}
public static void main(String[] args) {
	Swap.show(12, 13);
}
}
