package com.expHandlingThrow;

public class CustomException extends ArithmeticException {
public CustomException(String msg) {
	super(msg);
}
public static void main(String[] args) {
	//System.out.println(1/0);
	throw new CustomException("Denominator never be zero");
}

}
