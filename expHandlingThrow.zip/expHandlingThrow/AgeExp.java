package com.expHandlingThrow;

public class AgeExp extends Exception{
	
	public AgeExp(String msg) {
		super(msg);
	}
	   public static void checkAge(int age) throws AgeExp {
	        if (age < 18) {
	            throw new AgeExp("You must be at least 18 years old.");
	        } else {
	            System.out.println("Access granted.");
	        }
	    }

	    public static void main(String[] args) {
	       try {
	    	checkAge(16); // This will throw an exception
	    }catch(AgeExp e) {
	    	System.out.println("Caught exception : "+e.getMessage());
	    	e.printStackTrace();
	    }
}
}
