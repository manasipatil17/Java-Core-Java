package com.methods;

public class Square {

	public void sqr(int n) {
		int sq=n*n;
		System.out.println("Square of "+n+" is "+sq);
	}
}
