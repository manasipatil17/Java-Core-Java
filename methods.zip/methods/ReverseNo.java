package com.methods;

public class ReverseNo {

	public void reverse(int num){
		int n=num;
int rem;
int total=0;
while(num>0) {
	rem=num%10;
	total=total*10+rem;
	num=num/10;
}
System.out.println("Revese of "+n+" is "+total);
	}
}
