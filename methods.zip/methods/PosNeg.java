package com.methods;

public class PosNeg {

	public void PosNeg(int num) {
		if(num>0) {
			System.out.println(num+" is positive number");
		}
		else if(num<0) {
			System.out.println(num+" is negative number");
		}
		else {
			System.out.println("number is zero");
		}
	}
}
