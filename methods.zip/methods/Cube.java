package com.methods;

public class Cube {
public void cube(int a) {
int cu=a*a*a;
System.out.println("Cube of "+a+" is "+cu); 

}
}
