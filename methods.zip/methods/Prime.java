package com.methods;

public class Prime {
public void prime(int n) {
	int num=n;
	int count=0;
	while(n>0){
		n=n/10;
		count++;
	}
	if(count==2){
		System.out.println(num+" is prime number");
	}
	else {
		System.out.println(num+" is not prime number");
	}
}
}
