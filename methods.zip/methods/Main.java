package com.methods;

import java.util.Scanner;

public class Main {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	while(true) {
	System.out.println("Enter 1/2/3/4/5/6 : ");
	System.out.println("1 : To check sqaure of number");
	System.out.println("2 : To check cube of number");
	System.out.println("3 : To check number is even or odd");
	System.out.println("4 : To check number is positive or negative");
	System.out.println("5 : To check number is prime or not");
	System.out.println("6 : To check reverse number of given number");
	System.out.println("Enter any other btn to terminate application");
	int n=sc.nextInt();
	switch(n) {
	case 1:
		Square s=new Square();
		System.out.println("Enter the number : ");
		s.sqr(sc.nextInt());
		System.out.println("---------------------------------------------");
		break;
	case 2:
		Cube c=new Cube();
		System.out.println("Enter the number : ");
		c.cube(sc.nextInt());
		System.out.println("---------------------------------------------");
		break;
	case 3:
		EvenOdd e=new EvenOdd();
		System.out.println("Enter the number : ");
		e.op(sc.nextInt());
		System.out.println("---------------------------------------------");
		break;
	case 4:
		PosNeg p=new PosNeg();
		System.out.println("Enter the number : ");
		p.PosNeg(sc.nextInt());
		System.out.println("---------------------------------------------");
		break;
	case 5:
		Prime pr=new Prime();
		System.out.println("Enter the number : ");
		pr.prime(sc.nextInt());
		System.out.println("---------------------------------------------");
		break;
	case 6:
		ReverseNo r=new ReverseNo();
		System.out.println("Enter the number : ");
		r.reverse(sc.nextInt());
		System.out.println("---------------------------------------------");
		break;
	default:

		System.out.println("Application terminated...");
		System.exit(0);
	}	
	}
	
		
		
	
	
	
}
}
