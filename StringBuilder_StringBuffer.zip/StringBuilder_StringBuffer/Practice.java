package com.StringBuilder_StringBuffer;

//

public class Practice {
	
	
	public static void main(String[] args) {
		String str = "hello"; // immutable

		StringBuilder sb = new StringBuilder(str); // mutable
//	StringBuffer  sb = new StringBuffer(str);   
		sb.setCharAt(4, 'G');
		System.out.println(sb);
		sb.insert(1, "SB");
		System.out.println(sb);
		sb.delete(1, 5);
		System.out.println(sb);
		sb.append("World");
		System.out.println(sb);
		// Returns the current capacity. The capacity is the number of charactersthat
		// can be stored (including already written characters),
		// beyond whichan allocation will occur.
		System.out.println(sb.capacity());
		System.out.println(sb.reverse());
		
		
		
		
		
		

	}
}
