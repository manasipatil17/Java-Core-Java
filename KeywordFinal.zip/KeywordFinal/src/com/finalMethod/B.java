package com.finalMethod;

public class B extends A{
@Override
public void m2() {
System.out.println("m2 from B");	
}
	
public static void main(String[] args) {
	B b=new B();
	b.m1();
	b.m2();
}
}
