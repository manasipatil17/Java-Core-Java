package com.finalClass;

//public final class A

//we cannot inherit final class
public class A{
public void m1() {
	System.out.println("m1 form A");
}
}
