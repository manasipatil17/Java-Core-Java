package com.finalVariable;

public class Demo {
	
	final int b=30;
	
	
	public void m1() {
		final int a=20;
		System.out.println(a);
	
	}
	
	public void m2() {
		final int a=20;
		System.out.println(a);
	
	}

public static void main(String[] args) {
	Demo d=new Demo();
	System.out.println(d.b);
	d.m1();
	d.m2();
	}
}
