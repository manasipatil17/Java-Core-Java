package com.hw8_4.bank;

public class Bank {
//	Create a bank account with account holder name and initial balance.
//	   Deposit and withdraw money.
//	   Show current balance.

	String bankHolderName;
	double initialBalance;
	
	public Bank(String bankHolderName, double initialBalance ) {
		this.bankHolderName=bankHolderName;
		this.initialBalance=initialBalance;
		
	}
	
	public void deposit(double dAmount) {
		if(dAmount>0) {
		initialBalance+=dAmount;
		System.out.println("deposited "+dAmount);
		}
		else {
			System.out.println("Invalid deposit amount");
		}
	}
	
	public void withdraw(double wAmount) {
		if(wAmount>0&&wAmount<=initialBalance) {
		initialBalance-=wAmount;
		System.out.println("withdrew : " + wAmount);
	   }
		else {
			System.out.println("Invalid withdram amount");
		}
	}
	
	public void showDetails() {
		System.out.println("Account holder name is "+bankHolderName);
		System.out.println("Current balance is "+initialBalance);
	}
}
