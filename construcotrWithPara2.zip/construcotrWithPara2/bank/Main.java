package com.hw8_4.bank;

import java.util.Scanner;

public class Main {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("ENTER ACCOUNT HOLDER NAME : ");
	String name=sc.nextLine();
	System.out.println("ENTER INITIAL BALANCE : ");
	double iBalance=sc.nextDouble();
	Bank b=new Bank(name,iBalance);
	b.showDetails();
	System.out.println();
	while(true) {
		System.out.println("Enter 1 for deposit operation ");
		System.out.println("Enter 2 for withdraw opearation");
		System.out.println("Enter 3 for checking balance");
		System.out.println("Enter any other button to close application...");
		int btn=sc.nextInt();
	switch(btn) {
	case 1:
		System.out.println("Enter amount : ");
	b.deposit(sc.nextDouble());
	System.out.println();
	break;
	case 2:
		System.out.println("Enter amount : ");
	b.withdraw(sc.nextDouble());
	System.out.println();
	break;
	case 3:
		b.showDetails();
		System.out.println();
		break;
		
	default:
		System.out.println("Application terminated...");
		System.exit(0);

}
	}
}
}
