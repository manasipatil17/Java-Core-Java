package com.hw8_4.customer;

public class Customer {
	public double calculateTotalBill(int numberOfItems, double pricePerItem) {
        return numberOfItems * pricePerItem;
    }
    public double calculateGST(double totalAmount) {
        final double GST_RATE = 0.18; 
        return totalAmount * GST_RATE;
    }

    public double calculateTotalPayable(double totalAmount, double gstAmount) {
        return totalAmount + gstAmount;
    }

}
