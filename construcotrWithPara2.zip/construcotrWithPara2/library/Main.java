package com.hw8_4.library;

import java.util.Scanner;

public class Main {
public static void main(String[] args) {
	Scanner sc =new Scanner(System.in);
	System.out.println("Enter book title :");
	String title=sc.nextLine();
	System.out.println("Enter author name : ");
	String author = sc.nextLine();
	System.out.println("Enter price : ");
	double price=sc.nextDouble();
	
	Book b=new Book(title, author, price);
	b.showDetails();
	
}
}
