package com.hw8_4.library;

public class Book {
//	Input book title, author, price.
//	   Use constructor to initialize.
//	   Display book details using a method.

	String bTitle;
	String author;
	double price;
	
	public Book(String bTitle, String author, double price ) {
		this.bTitle=bTitle;
		this.author=author;
		this.price=price;
	}
	
	public void showDetails() {
		System.out.println("Book name : "+bTitle);
		System.out.println("Author : "+author);
		System.out.println("Price : "+price);
	}
}
