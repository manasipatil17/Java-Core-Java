package com.hw8_4.emp;

public class Employee {
//	Take employee details like name, ID, and basic salary.
//	   Calculate HRA, DA, and net salary.
//	   Print a formatted salary slip using methods
	
	int ID;
	String name;
	double salary;
	double hra;
	double da;
	double netSalary;
	
	public Employee(int ID, String name, double salary) {
		this.ID=ID;
		this.name=name;
		this.salary=salary;
	}
	
	public void calculateSalary() {
		hra=0.2*salary;
		da=0.1*salary;
		netSalary=salary+hra+da;
	}
	public void showDetails() {
		System.out.println("Employee ID : "+ID);
		System.out.println("Employee name : "+name);
		System.out.println("Basic salary : "+salary);
		System.out.println("HRA (20%) : "+hra);
		System.out.println("DA (10%) : "+da);
		System.out.println("Net salary : "+netSalary);
	}
	

}
