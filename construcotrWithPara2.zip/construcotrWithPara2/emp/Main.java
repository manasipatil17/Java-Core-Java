package com.hw8_4.emp;

import java.util.Scanner;

public class Main {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter employee ID : ");
	int id=sc.nextInt();
	sc.nextLine();
	System.out.println("Enter employee name : ");
	String name=sc.nextLine();
	System.out.println("Enter basic salary : ");
	double salary=sc.nextDouble();
	
	Employee e=new Employee(id, name, salary);
	e.calculateSalary();
    e.showDetails();
}
}
