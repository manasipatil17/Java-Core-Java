package com.hw8_4.calculator;

public class Logic {

	int num1;
	int num2;
	int sum;
	int sub;
	int mul;
	double div;

    public Logic(int num1, int num2) {
    	this.num1=num1;
    	this.num2=num2; 
    }
    
	public void addition() {
		sum = num1 + num2;
	
	}

	public void subtraction() {
		sub = num1 - num2;
	}

	public void multiplication() {
		mul = num1 * num2;
	}

	public void division() {
		if (num2 == 0) {
			System.out.println("Denominator should not be zero");

		} else {
			div = num1 / num2;
		}
	}

}
