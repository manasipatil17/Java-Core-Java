package com.hw8_4.calculator;

import java.util.Scanner;

public class Main {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	while(true) {
	System.out.println("Enter first number : ");
	int num1=sc.nextInt();
	sc.nextLine();
	System.out.println("Enter second number : ");
	int num2=sc.nextInt();
	sc.nextLine();
	Logic l=new Logic(num1,num2);
	
	System.out.println("Enter 1 for addition");
	System.out.println("Enter 2 for subtraction");
	System.out.println("Enter 3 for multiplication");
	System.out.println("Enter 4 for division");
	System.out.println("Enter any other button to stop the application");
	int btn = sc.nextInt();
	switch(btn) {
	case 1:
	l.addition();
	System.out.println(num1+" + "+num2+" = "+l.sum);
	break;
	case 2:
	l.subtraction();
	System.out.println(num1+" - "+num2+" = "+l.sub);
	break;
	case 3:
	l.multiplication();
	System.out.println(num1+" * "+num2+" = "+l.mul);
	break;
	case 4:
	l.division();
	System.out.println(num1+" / "+num2+" = "+l.div);
	break;
	default:
		System.out.println("Application terminated...");
		System.exit(8);
	}
	}
}
}
