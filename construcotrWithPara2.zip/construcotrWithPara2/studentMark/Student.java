package com.hw8_4.studentMark;

public class Student {

//	 Take student name, roll number, and marks for 3 subjects.
//	   Calculate total and average.
//	   Display grade (A/B/C/Fail) using if-else logic.

	int rollNo;
	String name;
	int mark1;
	int mark2;
	int mark3;
	int total;
	float average;
	
	public Student(int rollNo,String name,int mark1,int mark2,int mark3) {
		this.rollNo=rollNo;
		this.name=name;
		this.mark1=mark1;
		this.mark2=mark2;
		this.mark3=mark3;
	}
	public int total() {
		 total=mark1+mark2+mark3;
		return total;
	}
	public float avg() {
		 average=total/3;
		return average;
	}
	public void grade() {
		if(average>=90 &average<=100) {
			System.out.println("Grade : A");
		}
		else if(average>=80 &average<=89) {
			System.out.println("Grade : B");
		}
		else if(average>=70 &average<=79) {
			System.out.println("Grade : C");
		}
		else if(average>=60 &average<=69) {
			System.out.println("Grade : D");
		}
		else if(average>=36 &average<=59) {
			System.out.println("Grade : D");
		}
		
		else {
			System.out.println("Grade : Fail");
		}
	}
	public void display() {
		System.out.println("Roll no : "+rollNo);
		System.out.println("Name  : "+name);
		System.out.println("Total : "+total());
		System.out.println("Average  : "+avg());
	}
}
