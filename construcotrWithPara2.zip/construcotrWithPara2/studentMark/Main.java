package com.hw8_4.studentMark;

import java.util.Scanner;

public class Main {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter roll number : ");
	int rollNo=sc.nextInt();
	sc.nextLine();
	System.out.println("Enter name : ");
	String name=sc.nextLine();
	System.out.println("Enter mark of subject 1 : ");
	int mark1=sc.nextInt();
	System.out.println("Enter mark of subject 2 : ");
	int mark2=sc.nextInt();
	System.out.println("Enter mark of subject 3 : ");
	int mark3=sc.nextInt();
	
	Student s=new Student(rollNo, name, mark1, mark2, mark3);
	s.total();
	s.avg();
	s.display();
	s.grade();
}
}
