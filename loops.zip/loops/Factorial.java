package com.loops;

import java.util.Scanner;

public class Factorial {
public static void main(String[] args) {
	//Factorial of a Number
	//Find the factorial of a given number N using a for loop.
	int fact=1;
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter a number : ");
	int num=sc.nextInt();
	for( int i=num ;i>=1;i--) {
		fact*=i;
	}
	System.out.println("Factorial of "+num+" is "+fact);
	
}
}
