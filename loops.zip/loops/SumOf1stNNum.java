package com.loops;

public class SumOf1stNNum {
public static void main(String[] args) {
	//Sum of First N Natural Numbers
	//Calculate and print the sum of the first N natural numbers using a for loop.
    
	int sum=0;
	for(int i=1;i<=10;i++) {
		sum+=i;
	}
	System.out.println("sum of 1st n numbers is "+sum);
}
}
