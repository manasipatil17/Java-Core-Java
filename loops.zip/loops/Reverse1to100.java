package com.loops;

public class Reverse1to100 {
public static void main(String[] args) {
	for(int i=100;i>=1;i--) {
		System.out.println(i);
	}
}
}
