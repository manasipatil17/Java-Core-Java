package com.loops;

public class Even2To100 {
public static void main(String[] args) {
	//Print all even numbers from 2 to 100 using only a for loop.
	for(int i=2;i<=100;i++) {
		if(i%2==0) {
			System.out.println(i);
		}
	}
}
}
