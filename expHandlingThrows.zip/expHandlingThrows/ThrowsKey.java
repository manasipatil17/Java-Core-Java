package com.expHandlingThrows;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class ThrowsKey {

	public void m1() throws ClassNotFoundException{
		Class.forName("java.lang.String");
		System.out.println("String class opened");

		Class.forName("java.lang.Arrays");
		System.out.println("String class");
	}
	
	public void m2() throws FileNotFoundException {
		FileInputStream f=new FileInputStream("d/abc.txt");

	}
}
