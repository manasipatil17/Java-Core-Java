package com.expHandlingThrows;

import java.io.FileNotFoundException;

public class Main {
public static void main(String[] args)  {
	ThrowsKey t=new ThrowsKey();
	try {
		t.m1();
	} catch (ClassNotFoundException e) {
System.out.println("Exception displayed");
		//e.printStackTrace();
	}
	
	try {
		t.m2();
	} catch (FileNotFoundException e) {
	System.out.println("exception occurs for file");
		//e.printStackTrace();
	}
}
}
