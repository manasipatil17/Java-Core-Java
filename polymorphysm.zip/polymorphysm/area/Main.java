package com.polymorphysm.area;

public class Main {
	public static void main(String[] args) {
		Area a=new Area();
		a.area(5);
		a.area(10, 6);
		a.area(12);
	}

}
