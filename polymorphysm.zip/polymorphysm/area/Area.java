package com.polymorphysm.area;

public class Area {
//	1.Overload a method area() to calculate:
//		Area of a circle
//		Area of a rectangle
//		Area of a square

public void area(double radius) {
	System.out.println("Area of circle is "+(3.14*radius*radius));
}
public void area(int length, int width) {
	System.out.println("Area of rectangle is "+(length*width));
}
public void area(int side) {
	System.out.println("Area of square is "+(side*side));
}
}
