package com.polymorphysm.bank;

public class BankaAccount {
//	5.Create a BankAccount class with overloaded deposit() methods:
//		deposit(int amount)
//		deposit(int amount, String mode) (like "cash", "cheque")

public void deposit(int amount) {
	System.out.println(amount+" amount deposited");
}
public void deposit(int amount,String mode) {
	System.out.println(amount+" amount deposited and the mode is "+mode);
}

}
