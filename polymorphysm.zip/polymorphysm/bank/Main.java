package com.polymorphysm.bank;

public class Main {
public static void main(String[] args) {
	BankaAccount b=new BankaAccount();
	b.deposit(12000);
	b.deposit(15000, "cash");
}
}
