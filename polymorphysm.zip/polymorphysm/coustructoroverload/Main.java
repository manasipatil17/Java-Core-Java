package com.polymorphysm.coustructoroverload;

public class Main {
public static void main(String[] args) {
	Const c=new Const();
	Const c1=new Const(12);
	Const c2=new Const(12,"Om");
	
}
}
