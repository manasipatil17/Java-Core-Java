package com.polymorphysm.coustructoroverload;

public class Const {
//	4.Write a program to overload a constructor in a Student class:
//		Constructor 1: takes no arguments
//		Constructor 2: takes roll number
//		Constructor 3: takes roll number and name

	public Const() {
		System.out.println("This is no arg constructor");
	}
	public Const(int rollNo) {
		System.out.println("rollNo is "+rollNo);
	}
	public Const(int rollNo, String name) {
		System.out.println("rollNo is "+rollNo+" and name is "+name);
	}
}
