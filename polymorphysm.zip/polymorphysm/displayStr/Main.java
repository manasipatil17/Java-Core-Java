package com.polymorphysm.displayStr;

public class Main {
	public static void main(String[] args) {
		StringDisplay s=new StringDisplay();
		s.display(23);
		s.display("Manasi");
		s.display("Satara", 11);
	}

}
