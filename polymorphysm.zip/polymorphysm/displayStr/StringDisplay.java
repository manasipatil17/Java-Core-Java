package com.polymorphysm.displayStr;

public class StringDisplay {
//	3.Overload a method named display() to:
//		Display a string
//		Display an integer
//		Display a string and an integer together

public void display(String m) {
	System.out.println("string is "+m);
}

public void display(int m) {
	System.out.println("integer is "+m);
}

public void display(String m,int n) {
	System.out.println("String is "+m+" and integer is "+n);
}

}
