package com.polymorphysm.vehicle;

public class Car extends Vehicle{


	@Override
	public void move() {
		System.out.println("Car is moving");
	
}

}
