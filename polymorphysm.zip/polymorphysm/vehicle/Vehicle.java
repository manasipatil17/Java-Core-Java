package com.polymorphysm.vehicle;

public class Vehicle {
//	7.Create a class Vehicle with method move() and override it in:
//		Car class → "Car is moving"
//		Bike class → "Bike is moving"

	public void move() {
		System.out.println("Vehicle moves");
	}
}
