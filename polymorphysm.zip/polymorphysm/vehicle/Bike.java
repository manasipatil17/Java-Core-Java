package com.polymorphysm.vehicle;

public class Bike extends Vehicle{

	@Override
	public void move() {
		System.out.println("Bike is moving");
	
}
}