package com.polymorphysm.vehicle;

public class Main {
public static void main(String[] args) {
	Vehicle v=new Vehicle();
	Bike b=new Bike();
	Car c=new Car();
	v.move();
	b.move();
	c.move();
}
}
