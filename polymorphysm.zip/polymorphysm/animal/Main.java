package com.polymorphysm.animal;

public class Main {
public static void main(String[] args) {
	Animal a=new Animal();
	Dog d=new Dog();
	Cat c=new Cat();
	a.sound();
	d.sound();
	c.sound();
}
}
