package com.polymorphysm.animal;

public class Cat extends Animal{
	@Override
	public void sound() {
		System.out.println("Cat sounds Meow");
	}

}
