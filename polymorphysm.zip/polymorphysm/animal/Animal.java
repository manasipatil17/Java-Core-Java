package com.polymorphysm.animal;

public class Animal {
//	6.Create a superclass Animal with a method sound() and override it in:
//		Subclass Dog → prints "Bark"
//		Subclass Cat → prints "Meow"
public void sound() {
	System.out.println("Animal do sound");
}
}
