package com.polymorphysm.calci;

public class Calculator {
//	2.Create a Calculator class with overloaded add() methods:
//		add(int, int)
//		add(double, double)
//		add(int, int, int)

public void add(int a, int b) {
	System.out.println("addition of "+a+" and "+b+ " is "+(a+b));
}
public void add(double a, double b) {
	System.out.println("addition of "+a+" and "+b+ " is "+(a+b));
}
public void add(int a, int b,int c) {
	System.out.println("addition of "+a+" and "+b+ " and "+c+ " is "+(a+b+c));
}
}
