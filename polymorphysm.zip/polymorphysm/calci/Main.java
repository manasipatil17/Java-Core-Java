package com.polymorphysm.calci;

public class Main {
	public static void main(String[] args) {
		Calculator c=new Calculator();
		c.add(12, 040);
		c.add(12.5, 67.8);
		c.add(34, 54, 66);
	}

}
