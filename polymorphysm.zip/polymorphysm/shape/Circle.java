package com.polymorphysm.shape;

public class Circle extends Shape{

	@Override
	public void draw() {
		System.out.println("draw a circle");
	}

}
