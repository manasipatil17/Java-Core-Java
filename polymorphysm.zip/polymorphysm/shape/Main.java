package com.polymorphysm.shape;

public class Main {
public static void main(String[] args) {
	Shape s=new Shape();
	Circle c=new Circle();
	Rectangle r=new Rectangle();
	Triangle t=new Triangle();
	s.draw();
	c.draw();
	r.draw();
	t.draw();
}
}
