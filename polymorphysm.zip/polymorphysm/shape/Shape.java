package com.polymorphysm.shape;

public class Shape {

//8.Create a class Shape with method draw() and override it in:
//Circle class
//Rectangle class
//Triangle class

	public void draw() {
		System.out.println("draw the shape");
	}
}
