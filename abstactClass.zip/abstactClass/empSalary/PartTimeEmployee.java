package com.abstactClass.empSalary;

public class PartTimeEmployee extends Employee {

	private double hrsSalary;
	private double hrsWorked;
	public PartTimeEmployee(String name,double hrsSalary,double hrsWorked) {
		super(name);
		this.hrsSalary=hrsSalary;
		this.hrsWorked=hrsWorked;
		// TODO Auto-generated constructor stub
	}

	@Override
	public double calculateSalary() {
		
		return hrsSalary*hrsWorked;
	}

}
