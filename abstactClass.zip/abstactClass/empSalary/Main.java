package com.abstactClass.empSalary;

public class Main {
public static void main(String[] args) {
	FullTimeEmployee f=new FullTimeEmployee("Manasi", 40000);
	PartTimeEmployee p=new PartTimeEmployee("Ram", 2, 2000);
	
	System.out.println(f.name+" salary : "+f.calculateSalary());
	System.out.println(p.name+" salary : "+p.calculateSalary());
}
}
