package com.abstactClass.empSalary;

public class FullTimeEmployee extends Employee{
private double salary;
	public FullTimeEmployee(String name,double salary) {
		super(name);
		this.salary=salary;
		// TODO Auto-generated constructor stub
	}
	@Override
	public double calculateSalary() {
		
		return salary;
	}

}
