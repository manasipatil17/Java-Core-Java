package com.abstactClass.empSalary;

public abstract class Employee {
//Abstract class Employee with calculateSalary() as abstract. Implement for FullTimeEmployee and PartTimeEmployee.
String name;
public Employee(String name) {
	this.name=name;
	}
public abstract double calculateSalary();

}
