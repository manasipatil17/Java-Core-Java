package com.abstactClass.shape;

abstract class Shape {
	
	//Create an abstract class Shape with an abstract method calculateArea(). Implement it in Circle and Rectangle.

    public abstract double calculateArea();
}
