package com.interfaceePractice2.flight;

public class Main {
	 public static void main(String[] args) {
	        FlightService flight = new FlightService("Ananya Sharma");

	        flight.checkStatus();     
	        flight.bookTicket();       
	        flight.checkStatus();      
	        flight.cancelTicket();  
	        flight.checkStatus();    
	        flight.bookTicket();   
	    }
}
