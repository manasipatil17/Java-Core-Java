package com.interfaceePractice2.flight;

public interface Cancellation {
	void cancelTicket();
}
