package com.interfaceePractice2.flight;

public class FlightService implements Booking, Cancellation, TicketStatus {
    private String passengerName;
    private boolean isBooked = false;
    private boolean isCancelled = false;

    public FlightService(String passengerName) {
        this.passengerName = passengerName;
    }

    @Override
    public void bookTicket() {
        if (!isBooked) {
            isBooked = true;
            isCancelled = false;
            System.out.println("Ticket booked successfully for " + passengerName);
        } else {
            System.out.println("Ticket already booked for " + passengerName);
        }
    }

    @Override
    public void cancelTicket() {
        if (isBooked && !isCancelled) {
            isCancelled = true;
            System.out.println("Ticket cancelled for " + passengerName);
        } else if (!isBooked) {
            System.out.println("No booking found to cancel for " + passengerName);
        } else {
            System.out.println("Ticket already cancelled for " + passengerName);
        }
    }


    @Override
    public void checkStatus() {
        if (isBooked && !isCancelled) {
            System.out.println("Ticket is confirmed for " + passengerName);
        } else if (isCancelled) {
            System.out.println("Ticket is cancelled for " + passengerName);
        } else {
            System.out.println("No booking exists for " + passengerName);
        }
    }
}