package com.interfaceePractice2.flight;

public interface Booking {
	void bookTicket();
}
