package com.interfaceePractice2.flight;

public interface TicketStatus {
	void checkStatus();
}
