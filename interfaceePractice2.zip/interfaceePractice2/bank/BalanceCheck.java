package com.interfaceePractice2.bank;

public interface BalanceCheck {
	void checkBalance();
}
