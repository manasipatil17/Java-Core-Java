package com.interfaceePractice2.bank;

public interface Deposit {
//12.Create interfaces Deposit, Withdraw, and BalanceCheck, each with one method.
//	Implement them in a class BankApp to manage account operations.

	void deposit(double amount);
}
