package com.interfaceePractice2.bank;

public class BankApp implements Deposit, Withdraw, BalanceCheck {
    private double balance;

    public BankApp(double initialBalance) {
        this.balance = initialBalance;
    }

    @Override
    public void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
            System.out.println("Deposited: ₹" + amount);
        } else {
            System.out.println("Invalid deposit amount.");
        }
    }

    @Override
    public void withdraw(double amount) {
        if (amount <= balance && amount > 0) {
            balance -= amount;
            System.out.println("Withdrawn: ₹" + amount);
        } else {
            System.out.println("Insufficient balance or invalid withdrawal.");
        }
    }

    // Implement checkBalance method
    @Override
    public void checkBalance() {
        System.out.println("Current Balance: ₹" + balance);
    }
}


