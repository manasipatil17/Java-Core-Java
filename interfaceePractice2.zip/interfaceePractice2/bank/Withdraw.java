package com.interfaceePractice2.bank;

public interface Withdraw {
	void withdraw(double amount);
}
