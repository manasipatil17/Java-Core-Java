package com.interfaceePractice2.bank;

public class Main {
    public static void main(String[] args) {
        BankApp account = new BankApp(10000); // Start with ₹10,000

        account.checkBalance();
        account.deposit(2500);
        account.withdraw(3000);
        account.withdraw(15000); 
        account.checkBalance();
    }
}