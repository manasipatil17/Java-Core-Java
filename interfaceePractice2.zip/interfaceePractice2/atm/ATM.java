package com.interfaceePractice2.atm;

public interface ATM {
//7.Create an interface ATM with methods withdraw() and deposit(). Implement it in class Customer. Perform operations using interface reference.
	 void withdraw(double amount);
	    void deposit(double amount);
}
