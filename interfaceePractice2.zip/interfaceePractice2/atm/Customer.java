package com.interfaceePractice2.atm;

public class Customer implements ATM {
    private String name;
    private double balance;

    // Constructor
    public Customer(String name, double balance) {
        this.name = name;
        this.balance = balance;
    }

    @Override
    public void withdraw(double amount) {
        if (amount > balance) {
            System.out.println("Insufficient balance.");
        } else {
            balance -= amount;
            System.out.println("Withdrawn: " + amount);
            System.out.println("Remaining Balance: " + balance);
        }
    }

    @Override
    public void deposit(double amount) {
        balance += amount;
        System.out.println("Deposited: " + amount);
        System.out.println("New Balance: " + balance);
    }

    public void displayBalance() {
        System.out.println("Current Balance: " + balance);
    }
}

