package com.interfaceePractice2.atm;

public class Main {
	    public static void main(String[] args) {
	        ATM atm; 
	        Customer cust = new Customer("John Doe", 1000.00);

	        atm = cust; 

	        
	        atm.deposit(500.00);
	        atm.withdraw(300.00);
	        atm.withdraw(1500.00); 
	    }
	
}
