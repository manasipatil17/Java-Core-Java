package com.interfaceePractice2.nitification;

public interface Notification {
//4.Create a Notification interface with a method notifyUser(). Implement it in classes EmailNotification, SMSNotification, and PushNotification.
	void notifyUser();
}
