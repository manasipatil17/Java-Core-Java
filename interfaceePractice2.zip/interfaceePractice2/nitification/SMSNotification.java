package com.interfaceePractice2.nitification;

public class SMSNotification implements Notification {
    public void notifyUser() {
        System.out.println("Sending SMS notification...");
    }
}

