package com.interfaceePractice2.nitification;

public class Main {
	public static void main(String[] args) {
        
        Notification email = new EmailNotification();
        Notification sms = new SMSNotification();
        Notification push = new PushNotification();

       
        email.notifyUser();
        sms.notifyUser();
        push.notifyUser();
    }
}
