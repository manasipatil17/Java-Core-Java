package com.interfaceePractice2.nitification;

public class EmailNotification implements Notification {
    public void notifyUser() {
        System.out.println("Sending email notification...");
    }
}

