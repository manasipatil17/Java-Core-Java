package com.interfaceePractice2.nitification;

public class PushNotification implements Notification {
    public void notifyUser() {
        System.out.println("Sending push notification...");
    }
}
