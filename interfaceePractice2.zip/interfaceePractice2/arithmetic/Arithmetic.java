package com.interfaceePractice2.arithmetic;

public interface Arithmetic {
//11.Create interface Arithmetic with methods add(), subtract(), multiply(), and divide(). Implement all in class Calculator.
	double add(double a, double b);
    double subtract(double a, double b);
    double multiply(double a, double b);
    double divide(double a, double b);
}
