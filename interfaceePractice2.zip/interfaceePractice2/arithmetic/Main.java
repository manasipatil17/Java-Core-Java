package com.interfaceePractice2.arithmetic;

public class Main {
	public static void main(String[] args) {
        Calculator calc = new Calculator();

        double x = 20;
        double y = 5;

        System.out.println("Add: " + calc.add(x, y));
        System.out.println("Subtract: " + calc.subtract(x, y));
        System.out.println("Multiply: " + calc.multiply(x, y));
        System.out.println("Divide: " + calc.divide(x, y));
    }
}
