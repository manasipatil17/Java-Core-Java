package com.interfaceePractice2.shape;

public class Circle implements Shape{
private double r;

public Circle(double r) {
	this.r=r;
}
	@Override
	public void area() {
	System.out.println("Area of circle is "+(3.14*r*r));
		
	}
}
