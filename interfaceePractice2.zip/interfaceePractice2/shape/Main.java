package com.interfaceePractice2.shape;

public class Main {
	public static void main(String[] args) {
		Circle c=new Circle(3);
		Rectangle r=new Rectangle(12, 6);
		c.area();
		r.area();
	}

}
