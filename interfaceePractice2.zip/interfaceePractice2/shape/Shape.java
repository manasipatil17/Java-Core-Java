package com.interfaceePractice2.shape;

public interface Shape {
//1.Define an interface Shape with a method area(). Create two classes Rectangle and Circle 
	//that implement this interface and calculate the area accordingly.
      public abstract void area();
      
}
