package com.interfaceePractice2.amazon;

public class Main {
	 public static void main(String[] args) {
	        AmazonOrder order = new AmazonOrder("Noise Smartwatch", 3499.00);
	        order.placeOrder();
	        order.makePayment();
	        order.deliverOrder();
	    }
}
