package com.interfaceePractice2.amazon;

public interface OrderPlacement {
	 void placeOrder();
}
