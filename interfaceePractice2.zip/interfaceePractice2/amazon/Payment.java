package com.interfaceePractice2.amazon;

public interface Payment {
	void makePayment();
}
