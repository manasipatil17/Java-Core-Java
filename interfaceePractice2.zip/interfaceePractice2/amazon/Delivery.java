package com.interfaceePractice2.amazon;

public interface Delivery {
	void deliverOrder();
}
