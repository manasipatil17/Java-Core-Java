package com.interfaceePractice2.amazon;

public class AmazonOrder implements OrderPlacement, Payment, Delivery {
    private String itemName;
    private double amount;

    public AmazonOrder(String itemName, double amount) {
        this.itemName = itemName;
        this.amount = amount;
    }

    @Override
    public void placeOrder() {
        System.out.println("Order placed for: " + itemName);
    }

    @Override
    public void makePayment() {
        System.out.println("Payment of ₹" + amount + " done successfully.");
    }

    @Override
    public void deliverOrder() {
        System.out.println("Order for " + itemName + " has been shipped and will be delivered soon.");
    }
}
