package com.interfaceePractice2.transport;

public class Bus implements Transport {
    public void bookTicket() {
        System.out.println("Bus ticket booked.");
    }
}