package com.interfaceePractice2.transport;

public interface Transport {
//5. Design an interface Transport with method bookTicket(). Implement it in Bus, Train, and Flight. Show runtime polymorphism.
	void bookTicket();
}
