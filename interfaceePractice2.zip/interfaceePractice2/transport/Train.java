package com.interfaceePractice2.transport;

public class Train implements Transport {
    public void bookTicket() {
        System.out.println("Train ticket booked.");
    }
}
