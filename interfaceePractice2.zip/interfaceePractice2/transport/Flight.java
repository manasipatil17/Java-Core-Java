package com.interfaceePractice2.transport;

public class Flight implements Transport {
    public void bookTicket() {
        System.out.println("Flight ticket booked.");
    }
}