package com.interfaceePractice2.shopping;

public class CreditCardPayment implements ShoppingCart {
    public void checkout() {
        System.out.println("Order paid using Credit Card.");
    }
}
