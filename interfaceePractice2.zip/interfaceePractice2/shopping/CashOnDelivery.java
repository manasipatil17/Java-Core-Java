package com.interfaceePractice2.shopping;

public class CashOnDelivery implements ShoppingCart {
    public void checkout() {
        System.out.println("Order placed with Cash on Delivery.");
    }
}
