package com.interfaceePractice2.shopping;

public class Main {
	public static void main(String[] args) {
        ShoppingCart cart;

        cart = new CashOnDelivery();
        cart.checkout();  
        cart = new UPIPayment();
        cart.checkout();  
        cart = new CreditCardPayment();
        cart.checkout();     }

}
