package com.interfaceePractice2.shopping;

public class UPIPayment implements ShoppingCart {
    public void checkout() {
        System.out.println("Order paid using UPI.");
    }
}
