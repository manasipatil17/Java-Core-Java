package com.interfaceePractice2.shopping;

public interface ShoppingCart {
//6. Create a shopping cart interface with method checkout(). Implement it in classes like CashOnDelivery, UPIPayment, and CreditCardPayment.
	 void checkout();
}
