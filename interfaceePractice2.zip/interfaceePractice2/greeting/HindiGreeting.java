package com.interfaceePractice2.greeting;

public class HindiGreeting implements Greeting {
    @Override
    public void sayHello() {
        System.out.println("Namaste! Aap kaise hain?");
    }
}
