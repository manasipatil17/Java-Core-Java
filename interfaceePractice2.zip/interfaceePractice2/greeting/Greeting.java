package com.interfaceePractice2.greeting;

public interface Greeting {
//10.Create an interface Greeting with method void sayHello();
	//Create two classes EnglishGreeting and HindiGreeting that implement it.
	void sayHello(); 

}
