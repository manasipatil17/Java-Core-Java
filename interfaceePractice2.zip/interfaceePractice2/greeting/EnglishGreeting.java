package com.interfaceePractice2.greeting;

public class EnglishGreeting implements Greeting {
    @Override
    public void sayHello() {
        System.out.println("Hello! How are you?");
    }
}