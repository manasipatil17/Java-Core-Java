package com.interfaceePractice2.greeting;

public class Main {
	public static void main(String[] args) {
        Greeting greeting;

        greeting = new EnglishGreeting();
        greeting.sayHello();

       
        greeting = new HindiGreeting();
        greeting.sayHello();
    }
}
