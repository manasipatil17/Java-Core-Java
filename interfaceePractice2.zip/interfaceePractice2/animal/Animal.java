package com.interfaceePractice2.animal;

public interface Animal {
	//2.Create an interface Animal with a method sound(). Implement this interface in classes
	//Dog, Cat, and Cow, each printing its own sound.
void sound();
}
