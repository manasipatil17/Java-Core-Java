package com.interfaceePractice2.animal;

public class Cat implements Animal {
    public void sound() {
        System.out.println("Cat says: Meow!");
    }
}