package com.interfaceePractice2.animal;

public class Cow implements Animal {
    public void sound() {
        System.out.println("Cow says: Moo!");
    }
}

