package com.interfaceePractice2.onlinePaymentSystem;

public class CreditCardPayment implements PaymentGateway, RefundService, NotificationService {
	    private String cardHolder;

	    public CreditCardPayment(String cardHolder) {
	        this.cardHolder = cardHolder;
	    }

	    @Override
	    public void processPayment(double amount) {
	        System.out.println("Processing Credit Card payment of ₹" + amount + " for " + cardHolder);
	    }

	    @Override
	    public void refund(double amount) {
	        System.out.println("Refunding ₹" + amount + " to credit card of " + cardHolder);
	    }

	    @Override
	    public void sendNotification(String message) {
	        System.out.println("[Credit Card Notification] " + message);
	    }
	}

