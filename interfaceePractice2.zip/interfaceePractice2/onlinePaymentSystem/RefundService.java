package com.interfaceePractice2.onlinePaymentSystem;

public interface RefundService {
	void refund(double amount);
}
