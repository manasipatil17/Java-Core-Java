package com.interfaceePractice2.onlinePaymentSystem;

public interface NotificationService {
	void sendNotification(String message);

}
