package com.interfaceePractice2.onlinePaymentSystem;

public interface PaymentGateway {
	
	//15 . Design an online payment system using interfaces.
//Create the following three interfaces:
//PaymentGateway with method void processPayment(double amount);
//RefundService with method void refund(double amount);
//NotificationService with method void sendNotification(String message);
//Create two classes:
//CreditCardPayment implements all three interfaces and simulates payment via credit card.
//UPIPayment implements all three interfaces and simulates payment via UPI (e.g., Google Pay or PhonePe).
//From the main() method, demonstrate how both classes handle payment, refund, and sending notification.
	
	void processPayment(double amount);
}
