package com.interfaceePractice2.onlinePaymentSystem;

public class UPIPayment implements PaymentGateway, RefundService, NotificationService {
    private String upiId;

    public UPIPayment(String upiId) {
        this.upiId = upiId;
    }

    @Override
    public void processPayment(double amount) {
        System.out.println("Processing UPI payment of ₹" + amount + " from " + upiId);
    }

    @Override
    public void refund(double amount) {
        System.out.println("Refunding ₹" + amount + " to UPI ID " + upiId);
    }

    @Override
    public void sendNotification(String message) {
        System.out.println("[UPI Notification] " + message);
    }
}
