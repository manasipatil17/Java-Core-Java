package com.interfaceePractice2.onlinePaymentSystem;

public class Main {
	public static void main(String[] args) {
        // Credit Card Payment Flow
        CreditCardPayment creditPayment = new CreditCardPayment("Riya Kapoor");
        creditPayment.processPayment(1500);
        creditPayment.refund(300);
        creditPayment.sendNotification("₹300 has been refunded to your credit card.");

        System.out.println("----------------------------------");

        // UPI Payment Flow
        UPIPayment upiPayment = new UPIPayment("riya@okaxis");
        upiPayment.processPayment(1200);
        upiPayment.refund(200);
        upiPayment.sendNotification("₹200 has been refunded to your UPI ID.");
    }
}
