package com.interfaceePractice2.vehicle;

public class Bike implements Vehicle {
    public void startEngine() {
        System.out.println("Bike engine started: Brrrm Brrrm!");
    }
}
