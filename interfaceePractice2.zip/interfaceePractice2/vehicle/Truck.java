package com.interfaceePractice2.vehicle;

public class Truck implements Vehicle {
    public void startEngine() {
        System.out.println("Truck engine started: Rumble Rumble!");
    }
}
