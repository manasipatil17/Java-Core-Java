package com.interfaceePractice2.vehicle;

public class Car implements Vehicle {
    public void startEngine() {
        System.out.println("Car engine started: Vroom Vroom!");
    }
}