package com.interfaceePractice2.vehicle;

public class Main {
	public static void main(String[] args) {
       
        Vehicle car = new Car();
        Vehicle bike = new Bike();
        Vehicle truck = new Truck();

    
        car.startEngine();
        bike.startEngine();
        truck.startEngine();
    }
}
