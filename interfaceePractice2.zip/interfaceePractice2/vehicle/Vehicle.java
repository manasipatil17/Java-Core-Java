package com.interfaceePractice2.vehicle;

public interface Vehicle {
//	3.Create a program using an interface Vehicle with a method startEngine(). Implement it in classes Car, Bike, and Truck.
	void startEngine();
}
