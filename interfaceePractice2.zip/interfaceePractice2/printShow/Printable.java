package com.interfaceePractice2.printShow;

public interface Printable {
//8.Create two interfaces Printable and Showable with a method display(). Create a class Demo that implements both interfaces. How will you resolve the method conflict if both interfaces have default display() methods?
	default void display() {
		System.out.println("Display method from Printable");
		
	}
}
