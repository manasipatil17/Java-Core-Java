package com.interfaceePractice2.printShow;

public interface Showable {
	 default void display() {
		System.out.println("Display method from Showable");
		
	}
}
