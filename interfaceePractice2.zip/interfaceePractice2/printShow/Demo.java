package com.interfaceePractice2.printShow;

public class Demo implements Showable, Printable{

	@Override
	public void display() {
		Printable.super.display();
		System.out.println("Call from demo class");
	}
	
	public static void main(String[] args) {
		Demo d=new Demo();
		d.display();
	}
}


