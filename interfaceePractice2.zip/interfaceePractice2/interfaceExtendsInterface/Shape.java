package com.interfaceePractice2.interfaceExtendsInterface;

public interface Shape {
//9.Create interface Shape with method area(). Create another interface Displayable that extends Shape and adds method display(). Then, create a class Circle that implements Displayable.

	 double area();
}
