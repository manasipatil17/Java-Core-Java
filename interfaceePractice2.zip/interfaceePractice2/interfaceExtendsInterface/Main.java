package com.interfaceePractice2.interfaceExtendsInterface;

public class Main {
public static void main(String[] args) {
	Circle c=new Circle(4);
	c.display();
}
}
