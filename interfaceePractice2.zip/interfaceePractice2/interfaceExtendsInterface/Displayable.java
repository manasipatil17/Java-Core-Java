package com.interfaceePractice2.interfaceExtendsInterface;

public interface Displayable extends Shape{

	void display();
}
