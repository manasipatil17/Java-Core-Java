package com.arrayPractice1;

import java.util.Arrays;
import java.util.Scanner;

public class MaxNum {
	
	//create an array of 7 number. find and print the largest number.
public static void main(String[] args) {
	int n[]=new int[7];
	Scanner sc=new Scanner(System.in);
	for(int i=0;i<n.length;i++) {
			System.out.println("Enter number : ");
		n[i]=sc.nextInt();
	}
	System.out.println(Arrays.toString(n));
	int max=n[0];
	for(int i=0;i<n.length;i++) {
		if(max<n[i]) {
			max=n[i];
		}
	}
	System.out.println("Greatest number is "+max);
}
}
