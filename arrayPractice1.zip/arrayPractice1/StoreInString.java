package com.arrayPractice1;

public class StoreInString {
	
	//store 5 names in a string array and display them one by one
public static void main(String[] args) {
	String name[]=new String[5];
	name[0]="Manasi";
	name[1]="Ram";
	name[2]="Om";
	name[3]="Sita";
	name[4]="Raj";
	for(String nm: name) {
		System.out.println(nm);
	}
	
}
}
