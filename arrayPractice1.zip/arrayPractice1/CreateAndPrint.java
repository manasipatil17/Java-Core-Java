package com.arrayPractice1;

import java.util.Arrays;

public class CreateAndPrint {

	public static void main(String[] args) {
		//create array of 5 integers and print all of elements.
       //int a[]= {10,12,33,44,55};
       int a[]=new int[5];
       a[0]=10;
       a[1]=12;
       a[2]=33;
       a[3]=44;
       a[4]=55;
       
       System.out.println(Arrays.toString(a));
	}
}
