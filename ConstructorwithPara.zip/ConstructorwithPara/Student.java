package com.withPara;

public class Student {
	//Create a Student class with a parameterized constructor to initialize name and age, then
			//create an object and display the values
			
			public Student(String name, int age) {
	         System.out.println(name);
	         System.out.println(age);
			}
	
			public static void main(String[] args) {
				Student s=new Student("Manasi", 20);
				
			}

	}


