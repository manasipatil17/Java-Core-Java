package com.withPara;

public class Car {
	
	//Write a Java program to create a Car class with a parameterized constructor to initialize brand,
	//model, and price. Display car details.
		
		public Car(String brand, String model, String price) {
			System.out.println(brand);
			System.out.println(model);
			System.out.println(price);
		}

public static void main(String[] args) {
	Car c= new Car( "Kia","Seltos","11.3 Lakhs");
	
}
}
