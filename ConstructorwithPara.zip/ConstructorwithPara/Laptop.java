package com.withPara;

public class Laptop {
	
//Design a Laptop class with a parameterized constructor to initialize brand, ram, and storage.
//Print the laptop details.
		
public Laptop(String brand, String ram, String storage) {
	System.out.println(brand);
	System.out.println(ram);
	System.out.println(storage);
	
}

public static void main(String[] args) {
	Laptop l=new Laptop("DELL","16GB","500GB");
	
}
}
