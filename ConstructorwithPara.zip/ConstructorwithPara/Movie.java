package com.withPara;

public class Movie {
	// Write a Java program to create a Movie class with a parameterized constructor for movieName,
	// genre, and rating. Display movie details.

	public Movie(String movieName,String genre,int rating) {
		System.out.println(movieName);
		System.out.println(genre);
		System.out.println(rating);
	}
	public static void main(String[] args) {
		Movie m=new Movie("Inception","Sci-Fi",9);
		
	}

		
}
