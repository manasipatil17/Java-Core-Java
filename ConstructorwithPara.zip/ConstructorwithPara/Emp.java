	package com.withPara;

public class Emp {
	//Define an Employee class with a parameterized constructor that accepts id, name, and salary.
	//Print the employee details.

	public Emp(int id, String name, String salary) {
		System.out.println("Emp ID is "+id);
		System.out.println("Emp name is "+name);
		System.out.println("Emp salary is "+salary);
		
	}

	public static void main(String[] args) {
		Emp e=new Emp(1,"manasi","20000");
		
		
	}
	
}
