package com.withPara;

public class Rectangle {
	//Create a Rectangle class with a parameterized constructor that takes length and width as 
		//parameters. Calculate and display the area.
		
		public Rectangle(int length, int width) {
			System.out.println("Area of rectangle is: "+length*width);
			
		}
	 public static void main(String[] args) {
		Rectangle r=new Rectangle(22,12);
	

	}

}
