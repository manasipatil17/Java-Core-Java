package com.withPara;

public class Product {
	
//Create a Product class with a parameterized constructor that initializes productId, productName, 
//and price. Display the product details.
	public Product(int pID, String pName, int price) {
		System.out.println(pID);
		System.out.println(pName);
		System.out.println(price);
	}

public static void main(String[] args) {
	Product p=new Product(101, "watch", 3500);
	
}
}
