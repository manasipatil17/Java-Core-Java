package com.withPara;

public class Mobile {
//Create a Mobile class with a parameterized constructor that initializes brand, model, and price.
//Display mobile details.
		public Mobile(String brand, String model, int price) {
			System.out.println(brand);
			System.out.println(model);
			System.out.println(price);
		}
		public static void main(String[] args) {
			Mobile m=new Mobile("OPPO", "OPPO A54", 15000);
			
		}

}
