package com.thisKeyword;
public class Demo {
 int a=12;
 
 public Demo() {
	 this(1);
	 System.out.println("Demo 1");
 }
 public Demo(int a) {
	 this(1,2);
	 System.out.println("Demo 2");
	 System.out.println(a);
 }
 public Demo(int a, int b) {
	 System.out.println("Demo 3");
	 System.out.println(a+" "+b);
 }
 public void m2() {
	 System.out.println("this is m2 method");
 }
 public void m1() {
	 int a=16;
	 System.out.println(a);
	 System.out.println(this.a);//this with variable
	 this.m2();
 }
 
 public static void main(String[] args) {
	Demo d=new Demo();
	d.m1();
}
}


