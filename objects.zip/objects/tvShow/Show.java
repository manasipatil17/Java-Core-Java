package com.hw31_3.tvShow;

public class Show {
//Create a TVShow class with instance variables showName, genre, director, seasons, IMDBRating, 
	//and releaseYear. Create at least two objects, assign values, and print their details.

	String showName;
    String genre;
    String director;
    int seasons;
    double IMDBRating;
    int releaseYear;

}
