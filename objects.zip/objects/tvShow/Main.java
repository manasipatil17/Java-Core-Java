package com.hw31_3.tvShow;

public class Main {
public static void main(String[] args) {
	Show s=new Show();
	
	System.out.println("Show Name: " + (s.showName= "Breaking Bad"));
    System.out.println("Genre: " + (s.genre="Crime, Drama, Thriller"));
    System.out.println("Director: " + (s.director="Vince Gilligan"));
    System.out.println("Seasons: " + (s.seasons=5));
    System.out.println("IMDB Rating: " + (s.IMDBRating=9.5));
    System.out.println("Release Year: " + (s.releaseYear=2008));
    System.out.println("----------------------------");
    
    Show s1=new Show();
    System.out.println("Show Name: " + (s1.showName= "Stranger Things"));
    System.out.println("Genre: " + (s1.genre="Drama, Horror"));
    System.out.println("Director: " + (s1.director="The Duffer Brothers"));
    System.out.println("Seasons: " + (s1.seasons=4));
    System.out.println("IMDB Rating: " + (s1.IMDBRating=8.5));
    System.out.println("Release Year: " + (s1.releaseYear=2016));
    System.out.println("----------------------------");

    

}
}
