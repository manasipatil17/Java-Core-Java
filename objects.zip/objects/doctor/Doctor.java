package com.hw31_3.doctor;

public class Doctor {
//Create a Doctor class with instance variables doctorName, specialization, hospitalName, 
//experienceYears, consultationFee, contactNumber and hospitalLocation. Create at least two objects,
//assign values, and print their details.

	String doctorName;
    String specialization;
    String hospitalName;
    int experienceYears;
    double consultationFee;
    String contactNumber;
    String hospitalLocation;

}
