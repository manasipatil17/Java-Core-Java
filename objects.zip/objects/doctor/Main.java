package com.hw31_3.doctor;

public class Main {
public static void main(String[] args) {
	Doctor d=new Doctor();
	System.out.println("Doctor Name: " + (d.doctorName="Dr. John Smith"));
    System.out.println("Specialization: " + (d.specialization="Cardiologist"));
    System.out.println("Hospital Name: " + (d.hospitalName="HeartCare Hospital"));
    System.out.println("Years of Experience: " +(d. experienceYears=12));
    System.out.println("Consultation Fee: $" + (d.consultationFee= 150.00));
    System.out.println("Contact Number: " + (d.contactNumber= "123-456-7890"));
    System.out.println("Hospital Location: " + (d.hospitalLocation="New York"));
    System.out.println("-----------------------------");
    
    Doctor d1=new Doctor();
	System.out.println("Doctor Name: " + (d1.doctorName="Dr. Jane Doe"));
    System.out.println("Specialization: " + (d1.specialization="Neurologist"));
    System.out.println("Hospital Name: " + (d1.hospitalName= "BrainWell Clinic"));
    System.out.println("Years of Experience: " +(d1. experienceYears=8));
    System.out.println("Consultation Fee: $" + (d1.consultationFee= 120.00));
    System.out.println("Contact Number: " + (d1.contactNumber= "987-654-3210"));
    System.out.println("Hospital Location: " + (d1.hospitalLocation= "Los Angeles"));
    System.out.println("-----------------------------");
    
  

    
}
}
