package com.hw31_3.gadget;

public class Main {
	public static void main(String[] args) {
		
	Gadget g=new Gadget();
	System.out.println("Device Name: " + (g.deviceName="Smartphone"));
    System.out.println("Brand: " + (g.brand="Apple"));
    System.out.println("Price: $" + (g.price=999.99));
    System.out.println("Battery Life: " + (g.batteryLife=20) + " hours");
    System.out.println("Processor: " + (g.processor="A15 Bionic"));
    System.out.println("Warranty Period: " + (g.warrantyPeriod=2) + " years");
    System.out.println("-----------------------------");
    Gadget g1=new Gadget();
	System.out.println("Device Name: " + (g1.deviceName="Laptop"));
    System.out.println("Brand: " + (g1.brand="Dell"));
    System.out.println("Price: $" + (g1.price=799.99));
    System.out.println("Battery Life: " + (g1.batteryLife=10) + " hours");
    System.out.println("Processor: " + (g1.processor="Intel i7"));
    System.out.println("Warranty Period: " + (g1.warrantyPeriod=3) + " years");
    

}
}
