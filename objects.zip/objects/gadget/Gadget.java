package com.hw31_3.gadget;

public class Gadget {
	//Create a Gadget class with instance variables deviceName, brand, price, batteryLife, processor, 
	//and warrantyPeriod. Create at least two objects, assign values, and display their details.
		
	    String deviceName;
	    String brand;
	    double price;
	    int batteryLife; 
	    String processor;
	    int warrantyPeriod; 

}
