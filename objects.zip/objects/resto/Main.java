package com.hw31_3.resto;

public class Main {

	public static void main(String[] args) {
		Resto r=new Resto();
		System.out.println("Restaurant Name: " +( r.restaurantName="The Gourmet Hut"));
        System.out.println("Location: " + (r.location="New York"));
        System.out.println("Cuisine Type: " + (r.cuisineType="Italian"));
        System.out.println("Rating: " + (r.rating=4.5) + " out of 5");
        System.out.println("Number of Tables: " + (r.numTables=30));
        System.out.println("Owner Name: " + (r.ownerName="John Doe"));
        System.out.println("Online Rating: " + (r.onlineRating= 8.7) + " out of 10");
        System.out.println("-----------------------------");

        Resto r1=new Resto();
		System.out.println("Restaurant Name: " +( r1.restaurantName="Spice Fusion"));
        System.out.println("Location: " + (r1.location="Los Angeles"));
        System.out.println("Cuisine Type: " + (r1.cuisineType= "Indian"));
        System.out.println("Rating: " + (r1.rating=4.2) + " out of 5");
        System.out.println("Number of Tables: " + (r1.numTables=50));
        System.out.println("Owner Name: " + (r1.ownerName="Jane Smith"));
        System.out.println("Online Rating: " + (r1.onlineRating= 7.9) + " out of 10");
        System.out.println("-----------------------------");
        

        
	}
}
