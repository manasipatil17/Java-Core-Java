package com.hw31_3.resto;

public class Resto {
	//Create a Restaurant class with instance variables restaurantName, location, cuisineType, rating,
	//numTables, ownerName and onlineRating. Create at least two objects, assign values, and display 
	//their details.

	String restaurantName;
    String location;
    String cuisineType;
    double rating; 
    int numTables;
    String ownerName;
    double onlineRating; 

}
