package com.interfaceePractice1.payment;

public class GooglePay implements OnlinePayment{
	
	public void makePayment() {
		System.out.println("Amount payed successfully");
			
		}

}
