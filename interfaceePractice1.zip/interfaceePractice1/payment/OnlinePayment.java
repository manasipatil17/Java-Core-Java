package com.interfaceePractice1.payment;

public interface OnlinePayment {

//2.Create an one Interface OnlinePayment , it contains abstract makePayment() method. 
//create two classes PhonePay and GooglePay implements this to Bank interface. and write logic for 
//this method. 

	void makePayment();

}
