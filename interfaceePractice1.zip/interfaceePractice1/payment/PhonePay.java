package com.interfaceePractice1.payment;

public class PhonePay implements OnlinePayment {

	@Override
	public void makePayment() {
	System.out.println("Amount payed successfully");
		
	}

}
