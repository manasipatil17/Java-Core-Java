package com.interfaceePractice1.payment;

public class Main {
public static void main(String[] args) {
		GooglePay g=new GooglePay();
		g.makePayment();
		System.out.println("---------------------------");
		PhonePay p=new PhonePay();
		p.makePayment();
}
}
