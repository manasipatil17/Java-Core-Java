package com.interfaceePractice1.login;

public class Main {
public static void main(String[] args) {
	System.out.println("Admin Portal");
	Admin a =new Admin();
	a.authentiction("Ram", "Ram@123");
	System.out.println("-----------------------------------------");
	System.out.println("User Portal");
	User u=new User();
	u.authentiction("Manasi", "Manasi@123");
}
}
