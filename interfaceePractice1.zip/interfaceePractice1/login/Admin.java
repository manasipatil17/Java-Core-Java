package com.interfaceePractice1.login;

public class Admin implements Login{

	@Override
	public boolean authentiction(String username, String password) {
		if(username=="Ram" && password=="Ram@123") {
			System.out.println("Successfully login");
			return true;
		}
		else {
			System.out.println("Invalid credentials");
			return false;
	
		}
		
		
		
			}
	
	
}
