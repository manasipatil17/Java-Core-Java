package com.interfaceePractice1.login;

public interface Login {
	public abstract boolean authentiction(String username, String password);

}
