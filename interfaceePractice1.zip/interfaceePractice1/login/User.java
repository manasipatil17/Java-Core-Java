package com.interfaceePractice1.login;

public class User implements Login{

	@Override
	public boolean authentiction(String username, String password) {
		if(username.equals("Shriram") && password.equals("Shriram@123")) {
			System.out.println("Successfully login");
			return true;
		}
		else {
			System.out.println("Invalid credentials");
			return false;
	
		}
	}

}
