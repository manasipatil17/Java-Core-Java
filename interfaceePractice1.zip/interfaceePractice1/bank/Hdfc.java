package com.interfaceePractice1.bank;

public class Hdfc implements Bank {

	@Override
	public void interestRate() {
		// IMP NOTE : BY USING THE CLASS NAME OR INTERFACE NAME WE CAN CALL STATIC THINGS 

		System.out.println("HDFS interest rate : "+Bank.interestHdfc);
		
	}

}
