package com.interfaceePractice1.bank;

public class Sbi implements Bank {

	@Override
	public void interestRate() {
		System.out.println("SBI rate of interest : "+Bank.interestSbi);
		
	}

}
