package com.interfaceePractice1.bank;

public class Main {
public static void main(String[] args) {
	Sbi s=new Sbi();
	Hdfc h=new Hdfc();
	s.interestRate();
	h.interestRate();
}
}
