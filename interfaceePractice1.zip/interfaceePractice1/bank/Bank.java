package com.interfaceePractice1.bank;

public interface Bank {
public static final double interestSbi=7.8;
public static final double interestHdfc=9.0;
public abstract void interestRate();
}
