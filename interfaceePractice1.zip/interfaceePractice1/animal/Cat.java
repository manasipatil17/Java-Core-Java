package com.interfaceePractice1.animal;

public class Cat implements Animal{

	@Override
	public void sound() {
		System.out.println("Cat sounds meow");
		
	}

	@Override
	public void color() {
		System.out.println("Cat's color is black");
		
	}

}
