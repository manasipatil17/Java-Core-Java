package com.interfaceePractice1.animal;

public class Cow implements Animal{

	@Override
	public void sound() {
	         System.out.println("Cow sounds hmmmmmmm");
		
	}

	@Override
	public void color() {
		System.out.println("Cow's color is white");
		
	}

}
