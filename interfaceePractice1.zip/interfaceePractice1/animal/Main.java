package com.interfaceePractice1.animal;

public class Main {
public static void main(String[] args) {
	Cat c=new Cat();
	c.sound();
	c.color();
	System.out.println("-----------------------------");
	Dog d = new Dog();
	d.sound();
	d.color();
	System.out.println("---------------------------  ");
	Cow c1=new Cow();
	c1.sound();
	c1.color();
	
}
}
