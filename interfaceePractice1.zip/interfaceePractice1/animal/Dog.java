package com.interfaceePractice1.animal;

public class Dog implements Animal {

	@Override
	public void sound() {
		System.out.println("Dog barks");
		
	}

	@Override
	public void color() {
	System.out.println("Dog color is brown");
		
	}

}
