package com.interfaceePractice1.animal;

public interface Animal {
//3. Create an interface Animal with a abstract method sound() & Color(). Implement this 
//interface in classes Dog, Cat, and Cow, each printing its own sound & Color.
	 
	public abstract void sound();
	public abstract void color();


}
