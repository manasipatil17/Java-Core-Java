package com.hw13_3;

import java.util.Scanner;

public class ConverCurrency {
public static void main(String[] args) {
	/*Convert Currency (USD, INR, EUR)
Take a currency and convert it to another using predefined rates.*/

	Scanner scanner = new Scanner(System.in);
	
    System.out.println("Currency Converter");
    System.out.println("Choose the currency you want to convert from:");
    System.out.println("1. USD (US Dollar)");
    System.out.println("2. INR (Indian Rupee)");
    System.out.println("3. EUR (Euro)");
    System.out.print("Enter your choice (1/2/3): ");
    int fromCurrency = scanner.nextInt();

    System.out.println("Choose the currency you want to convert to:");
    System.out.println("1. USD (US Dollar)");
    System.out.println("2. INR (Indian Rupee)");
    System.out.println("3. EUR (Euro)");
    System.out.print("Enter your choice (1/2/3): ");
    int toCurrency = scanner.nextInt();

    System.out.print("Enter the amount to convert: ");
    double amount = scanner.nextDouble();

    double usdToInr = 75.0; // 1 USD = 75 INR
    double usdToEur = 0.92; // 1 USD = 0.92 EUR
    double inrToUsd = 1 / usdToInr; // 1 INR = 1/75 USD
    double inrToEur = inrToUsd * usdToEur; // 1 INR = 1/75 * 0.92 EUR
    double eurToUsd = 1 / usdToEur; // 1 EUR = 1/0.92 USD
    double eurToInr = eurToUsd * usdToInr; // 1 EUR = 1/0.92 * 75 INR

    double convertedAmount = 0.0;
    switch (fromCurrency) {
        case 1: 
            switch (toCurrency) {
                case 1:
                    convertedAmount = amount; // USD to USD
                    break;
                case 2:
                    convertedAmount = amount * usdToInr; // USD to INR
                    break;
                case 3:
                    convertedAmount = amount * usdToEur; // USD to EUR
                    break;
                default:
                    System.out.println("Invalid conversion choice.");
                    return;
            }
            break;

        case 2: // From INR
            switch (toCurrency) {
                case 1:
                    convertedAmount = amount * inrToUsd; // INR to USD
                    break;
                case 2:
                    convertedAmount = amount; // INR to INR (no change)
                    break;
                case 3:
                    convertedAmount = amount * inrToEur; // INR to EUR
                    break;
                default:
                    System.out.println("Invalid conversion choice.");
                    return;
            }
            break;

        case 3: // From EUR
            switch (toCurrency) {
                case 1:
                    convertedAmount = amount * eurToUsd; // EUR to USD
                    break;
                case 2:
                    convertedAmount = amount * eurToInr; // EUR to INR
                    break;
                case 3:
                    convertedAmount = amount; // EUR to EUR (no change)
                    break;
                default:
                    System.out.println("Invalid conversion choice.");
                    return;
            }
            break;

        default:
            System.out.println("Invalid currency choice.");
            return;
    }

    System.out.println("Converted Amount: " + convertedAmount);

}
}
