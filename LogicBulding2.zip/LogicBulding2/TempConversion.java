package com.hw13_3;

import java.util.Scanner;

public class TempConversion {
public static void main(String[] args) {
	/*
	 Convert Temperature Between Celsius and Fahrenheit
Use switch-case to select the conversion type.
	 */
	Scanner scanner = new Scanner(System.in);
    System.out.println("Temperature Conversion");
    System.out.println("Choose a conversion type:");
    System.out.println("1. Celsius to Fahrenheit");
    System.out.println("2. Fahrenheit to Celsius");
    System.out.print("Enter your choice (1/2): ");
    int choice = scanner.nextInt();

    double temperature, result;

    switch (choice) {
        case 1:
            System.out.print("Enter temperature in Celsius: ");
            temperature = scanner.nextDouble();
            result = (temperature * 9/5) + 32; 
            System.out.println(temperature + " Celsius is equal to " + result + " Fahrenheit.");
            break;

        case 2:
            System.out.print("Enter temperature in Fahrenheit: ");
            temperature = scanner.nextDouble();
            result = (temperature - 32) * 5/9;
            System.out.println(temperature + " Fahrenheit is equal to " + result + " Celsius.");
            break;
        default:
            System.out.println("Invalid choice! Please select 1 or 2.");
            break;
    }

}
}
