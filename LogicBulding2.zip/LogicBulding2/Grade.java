package com.hw13_3;

import java.util.Scanner;

public class Grade {
public static void main(String[] args) {
	/*Convert a Grade into Remarks
A = Excellent, B = Good, C = Average, D = Poor, F = Fail.*/
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter your grade : ");
	char grade= sc.next().charAt(0);
	switch(grade) {
	case 'A' : 
		System.out.println("A = Excellent");
		break;
	case 'B' : 
		System.out.println("B = Good");
		break;
	case 'C' : 
		System.out.println("C = Average");
		break;
	case 'D' : 
		System.out.println("D = Poor");
		break;
	case 'F' : 
		System.out.println("F = Fail");
		break;
	default:
		System.out.println("Enter correct grade...");
	}

}
}
