package com.hw13_3;

import java.util.Scanner;

public class PerfectSqr {
public static void main(String[] args) {
	/*
	 * Check if a Number is a Perfect Square
Use if-else to verify if the square root of the number is an integer.
	 */
    Scanner scanner = new Scanner(System.in);

    System.out.print("Enter a number: ");
    int number = scanner.nextInt();
    
    double squareRoot = Math.sqrt(number);

    if (squareRoot == (int) squareRoot) {
        System.out.println(number + " is a perfect square.");
    } else {
        System.out.println(number + " is not a perfect square.");
    }

}
}
