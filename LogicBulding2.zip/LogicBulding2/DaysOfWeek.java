package com.hw13_3;

import java.util.Scanner;

public class DaysOfWeek {
public static void main(String[] args) {
	/*Convert a Number (1-7) into a Weekday
1 = Sunday, 2 = Monday, ..., 7 = Saturday. */
	
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter a number from 1 to 7 to check weekday : ");
	int day=sc.nextInt();
	switch(day) {
	case 1 :
		System.out.println("1 = Sunday");
		break;
	case 2 :
		System.out.println("2 = Monday");
		break;
	case 3 :
		System.out.println("3 = Tuesday");
		break;
	case 4 :
		System.out.println("4 = Wednesday");
		break;
	case 5 :
		System.out.println("5 = Thursday");
		break;
	case 6 :
		System.out.println("6 = Friday");
		break;
	case 7 :
		System.out.println("7 = Saturday");
		break;
	default :
		System.out.println("Enter correct number");
	}

}
}
