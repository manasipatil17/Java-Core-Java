package com.hw13_3;

import java.util.Scanner;

public class ArithmeticOp {
public static void main(String[] args) {
	/*Menu-Based Program for Arithmetic Operations
Choose an operation (+, -, *, /) and perform it.*/
	
	Scanner sc=new Scanner(System.in);
	System.out.println("Choose the operation : ");
	System.out.println("1 Addition (+)");
	System.out.println("2 Subtraction (-)");
	System.out.println("3 Multiplication (*)");
	System.out.println("4 Division (/)");
	System.out.println("Enter your choice 1/2/3/4 : ");
	int choice=sc.nextInt();
	System.out.println("Enter first number : ");
	int num1=sc.nextInt();
	System.out.println("Enter second number : ");
	int num2=sc.nextInt();
	int ans=0;
	switch(choice) {
	case 1:
		ans=num1+num2;
		System.out.println(num1+"+"+num2+"="+ans);
		break;
	case 2:
		ans=num1-num2;
		System.out.println(num1+"-"+num2+"="+ans);
		break;
	case 3:
		ans=num1*num2;
		System.out.println(num1+"*"+num2+"="+ans);
		break;
	case 4:
		if (num2 != 0) {
            ans = num1 / num2;
            System.out.println("Result: " + num1 + " / " + num2 + " = " + ans);
        } else {
            System.out.println("Error: Division by zero is not allowed.");
        }
		break;
	default:
		System.out.println("Invalid choice...");
	
	
	}

}
}
