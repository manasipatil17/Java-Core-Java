package com.hw13_3;

import java.util.Scanner;

public class NoOfDaysInMonthYear {
public static void main(String[] args) {
	/*Find the Number of Days in a Given Month and Year
Consider leap years while checking February.*/
	
Scanner sc=new Scanner(System.in);
System.out.println("Enter year : ");
int year =sc.nextInt();
System.out.println("Enter month : ");
int month=sc.nextInt();

switch(month) {
case 1:
case 3:
case 5:
case 7:
case 8:
case 10:
case 12:
	System.out.println("days = 31");
	break;
case 4:
case 6:
case 9:
case 11:
	System.out.println("days = 30");
	break;
case 2:
	if(year%4==0) {
		System.out.println("days = 29");
	}
	else {
		System.out.println("days = 28");
	}
}

}
}
