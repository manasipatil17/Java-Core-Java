package com.hw13_3;

public class PalindromeOrNot {
public static void main(String[] args) {
	/*Check if a Number is a Palindrome
      Reverse a number and check if it remains the same.
      Find the Smallest of Three Numbers*/

//	int num = 43534;
//	int n = num;
//
//	int rem = 0;
//	int num2 = 0;
//	while (num > 0) {
//		rem = num % 10;
//		num2 = num2 * 10 + rem;
//		num = num / 10;
//	}
//	if (n == num2) {
//		System.out.println("Number is palindrome");
//	} else {
//		System.out.println("Not Palindrome");
//	}

	int num=12321;
	int n=num;
	int rem;
	int num2=0;
	while(num>0) {
		rem=num%10;
		num2=num2 *10+rem;
		num=num/10;
	}
	if(num2==n) {
		System.out.println("Palindrome");
	}
}
}
