package com.hw13_3;

import java.util.Scanner;

public class ZodiacSign {
public static void main(String[] args) {
	/*Aries (♈): March 21 – April 19
Taurus (♉): April 20 – May 20
Gemini (♊): May 21 – June 21
Cancer (♋): June 22 – July 22
Leo (♌): July 23 – August 22
Virgo (♍): August 23 – September 22
Libra (♎): September 23 – October 23
Scorpio (♏): October 24 – November 21
Sagittarius (♐): November 22 – December 21
Capricorn (♑): December 22 – January 19
Aquarius (♒): January 20 – February 18
Pisces (♓): February 19 – March 20*/
	
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter month in number 1-12 : ");
	int month=sc.nextInt();

	System.out.println("Enter date in number 1-31 : ");
	int date=sc.nextInt();
	
	
	switch (month) {
	case 1 :
		if(date>=20 && date<=31) {
			System.out.println("Aquarius");
		}
		else {
			System.out.println("Capricorn");
		}
		break;
	case 2 :
		if(date>=19 && date<=29) {
			System.out.println("Pisces");
		}
		else {
			System.out.println("Aquarius");
		}
		break;
	case 3:
		if(date>=21 && date<=31) {
			System.out.println("Aries");
		}
		else {
			System.out.println("Pisces");
		}
		break;
	case 4:
		if(date>=20 && date<=30) {
			System.out.println("Taurus");
		}
		else {
			System.out.println("Aries");
		}
		break;
	case 5:
		if(date>=21 && date<=31) {
			System.out.println("Gemini");
		}
		else {
			System.out.println("Taurus");
		}
		break;
	case 6:
		if(date>=22 && date<=30) {
			System.out.println("Cancer");
		}
		else {
			System.out.println("Gemini");
		}
		break;
	case 7:
		if(date>=23 && date<=31) {
			System.out.println("Leo");
		}
		else {
			System.out.println("Cancer");
		}
		break;
	case 8:
		if(date>=23 && date<=31) {
			System.out.println("Virgo");
		}
		else {
			System.out.println("Leo");
		}
		break;
	case 9:
		if(date>=23 && date<=30) {
			System.out.println("Libra");
		}
		else {
			System.out.println("Vigro");
		}
		break;
	case 10:
		if(date>=24 && date<=31) {
			System.out.println("Scorpio");
		}
		else {
			System.out.println("Libra");
		}
		break;
	case 11:
		if(date>=22 && date<=30) {
			System.out.println("Sagittarius");
		}
		else {
			System.out.println("Scorpio");
		}
		break;
	case 12:
		if(date>=22 && date<=31) {
			System.out.println("Capricorn");
		}
		else {
			System.out.println("Sagittarius");
		}
		break;
	default:
		System.out.println("Check the date or month...");
	
	
	
	}
}
}
