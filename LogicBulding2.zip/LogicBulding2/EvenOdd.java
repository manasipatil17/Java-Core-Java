package com.hw13_3;

import java.util.Scanner;

public class EvenOdd {
public static void main(String[] args) {
	/*Check if a Given Number is Odd or Even Using Switch
Use modulo operation inside switch-case.*/
    Scanner scanner = new Scanner(System.in);

    System.out.print("Enter a number: ");
    int number = scanner.nextInt();
   switch (number % 2) {
        case 0: 
            System.out.println(number + " is Even.");
            break;

        case 1:
            System.out.println(number + " is Odd.");
            break;

        default:
            System.out.println("Something went wrong!");
            break;
    }


}
}
