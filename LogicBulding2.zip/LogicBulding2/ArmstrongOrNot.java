package com.hw13_3;

public class ArmstrongOrNot {
public static void main(String[] args) {
	/*
Check if a Number is an Armstrong Number
Find if the sum of cubes of digits equals the number itself.
*/
//	int num = 153;
//	int num2 = num;
//	int power = 0;
//	int rem = 0;
//	int temp = 0;
//	int add = 0;
//
//	while (num > 0) {
//		num = num / 10;// 
//		power++;
//	}
//
//	num = num2;
//
//	while (num > 0) {
//		rem = num % 10;
//		temp = (int) Math.pow(rem, power);// 
//		add = add + temp;
//		num = num / 10;
//	}
//
//	if (num2 == add) {
//		System.out.println("Number is Armstrong");
//	} else {
//		System.out.println("Number is not Armstrong");
//	}
//

	int num=153;
	int num2=num;
	int power =0;
	int rem;
	int temp;
	int sum=0;
	while(num>0) {
	num=num/10;	
	power++;
	}
	num=num2;
	while(num>0) {
		rem=num%10;
		temp=(int)Math.pow(rem, power);
		sum=sum+temp;
		num=num/10;
	}
	if(sum==num2) {
		System.out.println("num is arm");
	}
	else {
		System.out.println("num is not armstrong");
	}
}
}
