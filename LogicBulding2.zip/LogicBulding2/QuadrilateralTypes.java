package com.hw13_3;

import java.util.Scanner;

public class QuadrilateralTypes {
public static void main(String[] args) {
	/*Find the Type of Quadrilateral
Choose between square, rectangle, parallelogram, and classify it.*/
	Scanner scanner = new Scanner(System.in);

    System.out.println("Enter the properties of the quadrilateral:");
    
    System.out.print("Enter the length of side 1: ");
    double side1 = scanner.nextDouble();
    System.out.print("Enter the length of side 2: ");
    double side2 = scanner.nextDouble();
    System.out.print("Enter the length of side 3: ");
    double side3 = scanner.nextDouble();
    System.out.print("Enter the length of side 4: ");
    double side4 = scanner.nextDouble();
    
    System.out.print("Enter the angle between side 1 and side 2 (in degrees): ");
    double angle1 = scanner.nextDouble();
    System.out.print("Enter the angle between side 2 and side 3 (in degrees): ");
    double angle2 = scanner.nextDouble();
    System.out.print("Enter the angle between side 3 and side 4 (in degrees): ");
    double angle3 = scanner.nextDouble();
    System.out.print("Enter the angle between side 4 and side 1 (in degrees): ");
    double angle4 = scanner.nextDouble();
    
    if (angle1 + angle2 + angle3 + angle4 != 360) {
        System.out.println("Invalid Quadrilateral (Sum of angles must be 360 degrees).");
    }

    // Check for square: All sides are equal and all angles are 90 degrees
    else if (side1 == side2 && side2 == side3 && side3 == side4 && angle1 == 90 && angle2 == 90 && angle3 == 90 && angle4 == 90) {
        System.out.println("Square"); 
    }

    // Check for rectangle: Opposite sides are equal and all angles are 90 degrees
    else if (side1 == side3 && side2 == side4 && angle1 == 90 && angle2 == 90 && angle3 == 90 && angle4 == 90) {
        System.out.println("Rectangle"); 
    }

    // Check for parallelogram: Opposite sides are equal and opposite angles are equal
    else if (side1 == side3 && side2 == side4 && angle1 == angle3 && angle2 == angle4) {
         System.out.println( "Parallelogram");
    }
    else {
    	System.out.println("Other type of quadrilateral...");
    }
}
}
