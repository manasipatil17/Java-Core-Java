package com.hw13_3;

import java.util.Scanner;

public class CheckCharacterOfAlphabets {
public static void main(String[] args) {
	/* Check if a Character is an Alphabet
Determine whether a given character is A-Z or a-z. */
	
	Scanner scanner = new Scanner(System.in);

    System.out.print("Enter a character: ");
    char ch = scanner.next().charAt(0); 

    if ((ch >= 'A' && ch <= 'Z') || (ch >= 'a' && ch <= 'z')) {
        System.out.println(ch + " is an alphabet.");
    } else {
        System.out.println(ch + " is not an alphabet.");
    }

}
}
