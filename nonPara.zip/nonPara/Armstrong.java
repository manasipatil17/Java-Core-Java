package com.nonPara;

public class Armstrong {
	public Armstrong() {
		int num=153;
		int n=num;
		int power=0;
		int rem;
		int num2;
		int sum=0;
		while(num>0) {
		num=num/10;
		power++;
		}
		num=n;
		
		while(num>0) {
			rem=num%10;
			num2=(int)Math.pow(rem, power);
			sum=sum+num2;
			num=num/10;
		}
		if(n==sum) {
			System.out.println("Armstrong");
		}
		else {
			System.out.println("Not armstrong");
		}
		}
public static void main(String[] args) {
	Armstrong a=new Armstrong();
}
}
