package com.nonPara;

public class Rectangle {
	public Rectangle() {
		int l=10;
		int b=12;
		System.out.println("Area of rectangle is "+l*b);
	}
public static void main(String[] args) {
	Rectangle r=new Rectangle();
	
}
}
