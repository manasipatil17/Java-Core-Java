package com.nonPara;

public class EvenOdd {
 public EvenOdd(){
	int a=3;
	if(a%2==0) {
		System.out.println("Given num is even");
	}
	else {
		System.out.println("Given num is odd");
	}
}
 public static void main(String[] args) {
	EvenOdd e=new EvenOdd();
}
}
