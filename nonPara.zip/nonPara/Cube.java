package com.nonPara;

public class Cube {
	public Cube() {
		int a=3;
		int b=a*a*a;
		System.out.println("Cube of "+a+" is "+b);
	}
public static void main(String[] args) {
	Cube c=new Cube();
}
}
