package com.nonPara;

public class Table {
public Table() {
	int a=10;
	for(int i=1;i<=10;i++) {
		System.out.println(a+"*"+i+"="+a*i);
	}
}
public static void main(String[] args) {


Table t=new Table();

}}
